"""Correct transcript serialization; preserve preliminary outputs and unchanged fact inventories."""
import atexit
import json
import shutil
from datetime import datetime, timezone

import run

atexit.register(run.cleanup_client_signin)
root = run.ROOT.resolve()
assert root == run.Path(r'{EXPERIMENT_ROOT}').resolve()
archive = root / 'private' / 'revisions' / 'transcript-v1'
archive.mkdir(parents=True, exist_ok=False)


def move_inside(source, target):
    assert source.resolve().is_relative_to(root) and target.resolve().is_relative_to(root)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(source), str(target))


for name in ['frozen','frozen-at.json','handoffs-order.json','handoffs-errors.json']:
    source = root / name
    if source.exists():
        move_inside(source, archive / name)
completed = 0
for n in range(1,4):
    run_id = f'coding-{n:02}'
    folder = root / 'runs' / run_id
    backup = archive / 'runs' / run_id
    backup.mkdir(parents=True)
    for name in ['handoff-history.txt','handoff-history.json','audit.json']:
        shutil.copyfile(folder / name, backup / name)
    if (folder / 'handoffs').exists():
        completed += len(list((folder/'handoffs').rglob('metadata.json')))
        move_inside(folder/'handoffs',backup/'handoffs')
    history = run.read_json(folder/'handoff-history.json')
    turn = 0
    parts = []
    for i,entry in enumerate(history):
        if entry['role']=='assistant':
            turn += 1
            raw = (folder/'raw'/f'turn-{turn:02}'/'output.txt').read_text(encoding='utf-8')
            entry['raw_visible_output'] = raw
            content = raw
        else:
            content = entry['content'] if isinstance(entry['content'],str) else json.dumps(entry['content'],ensure_ascii=False,indent=2)
        parts.append(f'[{i:03d}] {entry["role"].upper()}\n' + content)
    run.write_json(folder/'handoff-history.json',history)
    (folder/'handoff-history.txt').write_text('\n\n'.join(parts)+'\n',encoding='utf-8')
    keypath = run.PRIVATE/'answer-keys'/f'{run_id}.json'
    key = run.read_json(keypath)
    original_key = run.read_json(archive/'frozen'/f'{run_id}-answer-key.json')
    assert key['facts'] == original_key['facts'] and key['questions'] == original_key['questions']
    key['history_sha256'] = run.digest(folder/'handoff-history.txt')
    key['transcript_revision'] = 'v2: original visible assistant output, including JSON fences, rendered verbatim; facts/questions unchanged'
    run.write_json(keypath,key)
    audit = run.read_json(folder/'audit.json')
    audit['previous_handoff_history_sha256'] = audit['handoff_history_sha256']
    audit['handoff_history_sha256'] = key['history_sha256']
    audit['transcript_revision'] = 2
    run.write_json(folder/'audit.json',audit)
# Keep the executable renderer consistent for future reproduction, without changing model prompts.
path = root/'run.py'
s = path.read_text(encoding='utf-8')
s = s.replace('entry = {"role": "assistant", "content": action}', 'entry = {"role": "assistant", "content": action, "raw_visible_output": output + "\\n"}', 1)
start = s.index('    history_text = "\\n\\n".join(')
end = s.index('    (run_dir / "handoff-history.txt").write_text',start)
s = s[:start] + '''    history_text = "\\n\\n".join(
        f"[{i:03d}] {entry['role'].upper()}\\n" + (
            entry["raw_visible_output"] if entry.get("raw_visible_output") else
            entry["content"] if isinstance(entry["content"], str) else
            json.dumps(entry["content"], ensure_ascii=False, indent=2)
        )
        for i, entry in enumerate(handoff_history)
    )
''' + s[end:]
path.write_text(s,encoding='utf-8')
revision = {'at_utc':datetime.now(timezone.utc).isoformat(),'reason':'The v1 normalized display moved surrounding Markdown fences away from their JSON, making ordinary code blocks appear empty. Render original visible assistant responses verbatim.', 'preliminary_handoffs_completed':completed,'scored_receiving_quizzes_before_repair':0,'excluded_outputs':str(archive.relative_to(root)), 'coding_runs_reused':'All three original runs and original native outputs; no coding inference repeated.', 'fact_inventories_and_questions_unchanged':True,'model_prompts_and_model_settings_unchanged':True,'rerun_policy':'Regenerate all 24 handoffs from repaired transcripts, irrespective of preliminary quality; preserve every preliminary output; never retry for word count or content quality.'}
run.write_json(root/'transcript-revision.json',revision)
for name in ['protocol.json','pre-scored-settings.json']:
    p = root/name
    shutil.copyfile(p,archive/name)
    data = run.read_json(p)
    data['transcript_revision'] = revision
    run.write_json(p,data)
run.freeze()
run.write_json(root/'frozen-at.json',{'at_utc':datetime.now(timezone.utc).isoformat(),'revision':2,'all_keys_validated':True,'scored_handoffs_started':False})
status = run.read_json(root/'STATUS.json')
status['stage'] = 'Transcript v2 frozen; eight preliminary handoffs preserved/excluded; all 24 handoffs restart from faithful original visible output'
run.write_json(root/'STATUS.json',status)
print(json.dumps(revision,indent=2))