"""Create source-evidenced keys only after all three coding histories exist."""

import re
from datetime import datetime, timezone

import run

ROOT = run.ROOT


def main():
    for number in range(1, 4):
        assert (ROOT / "runs" / f"coding-{number:02}" / "audit.json").exists(), (
            "All coding histories must precede key preparation"
        )
    assert not (ROOT / "frozen").exists()
    for number in range(1, 4):
        run_id = f"coding-{number:02}"
        folder = ROOT / "runs" / run_id
        assert not (folder / "handoffs").exists(), "No scored handoff may precede keys"
        history = run.read_json(folder / "handoff-history.json")

        def find(role, action, path=None):
            return [
                i
                for i, e in enumerate(history)
                if e["role"] == role
                and isinstance(e["content"], dict)
                and e["content"].get("action") == action
                and (path is None or e["content"].get("path") == path)
            ]

        spec = find("tool", "read_file", "llm-health.md")[0]
        writes = find("assistant", "write_file", "llm.py")
        write = writes[-1]
        write_result = write + 1
        test_results = find("tool", "run_tests")
        test = test_results[-1]
        assert history[test]["content"]["exit_code"] == 0
        assert "Ran 30 tests" in history[test]["content"]["output"]
        facts = []

        def add(
            fid,
            qid,
            claim,
            entry,
            excerpt,
            interpretation="Equivalent semantic wording receives credit; no outside knowledge is inferred.",
        ):
            facts.append(
                {
                    "id": fid,
                    "question_id": qid,
                    "claim": claim,
                    "source_evidence": [{"entry": entry, "excerpt": excerpt}],
                    "interpretation": interpretation,
                }
            )

        add("Q1.1", "Q1", "llm.py was the only file changed.", write_result, "llm.py")
        facts[-1]["source_evidence"].append(
            {"entry": write_result, "excerpt": "written"}
        )
        add(
            "Q2.1",
            "Q2",
            "The standalone test_probe.py suite was executed in the offline container.",
            test,
            "python -B test_probe.py in the read-only offline container",
        )
        add(
            "Q2.2", "Q2", "The final recorded suite ran 30 tests.", test, "Ran 30 tests"
        )
        add(
            "Q2.3", "Q2", "The final recorded suite passed (OK / exit 0).", test, "OK\n"
        )
        for j, result in enumerate(test_results[:-1], 1):
            data = history[result]["content"]
            if data["exit_code"] != 0:
                summary = re.search(r"FAILED \([^\n]+\)", data["output"])
                add(
                    f"Q2.B{j}",
                    "Q2",
                    "An earlier recorded suite failed before the final successful check.",
                    result,
                    summary.group(0),
                )
        add(
            "Q3.1",
            "Q3",
            "HTTP was simulated.",
            0,
            "The provided tests simulate HTTP and time",
        )
        add(
            "Q3.2",
            "Q3",
            "Time was simulated.",
            0,
            "The provided tests simulate HTTP and time",
        )
        add(
            "Q3.3",
            "Q3",
            "Verification was module-only; Django routes were not verified.",
            test,
            "module only. No live provider, deployment, Django route or database verification.",
        )
        add(
            "Q3.4",
            "Q3",
            "No live provider verification was performed.",
            test,
            "No live provider",
        )
        add("Q3.5", "Q3", "Deployment was not verified.", test, "deployment")
        add(
            "Q3.6",
            "Q3",
            "The database was not verified.",
            test,
            "database verification",
        )
        add(
            "Q3.7",
            "Q3",
            "Production network timing was not verified.",
            0,
            "not Django routes or production network timing",
        )
        add(
            "Q4.1",
            "Q4",
            "A total 10-second deadline was implemented.",
            write,
            "TIMEOUT_SECONDS = 10",
        )
        message = history[write]["content"]["message"]
        assert "monotonic" in message and ("read" in message and "open" in message)
        add(
            "Q4.2",
            "Q4",
            "The same total deadline covers connection opening and response-body reading.",
            write,
            message,
        )
        add(
            "Q4.3",
            "Q4",
            "The deadline is based on monotonic time.",
            write,
            "time.monotonic",
        )
        assert "socket" in message and (
            "remaining" in message or "time left" in message
        )
        add(
            "Q4.4",
            "Q4",
            "The socket read timeout is set from the remaining total time budget.",
            write,
            message,
            "Per-read timeouts alone do not state that they use the remaining total budget.",
        )
        reason_entries = [
            i
            for i, e in enumerate(history)
            if e["role"] == "assistant"
            and "per-socket timeout" in e["content"]["message"]
        ]
        if reason_entries:
            i = reason_entries[0]
            add(
                "Q4.5",
                "Q4",
                "The recorded rationale distinguishes a total deadline from a per-socket timeout.",
                i,
                history[i]["content"]["message"],
                "Requires an explicit total-versus-per-operation distinction; a bare total-deadline claim earns Q4.1 only.",
            )
        add(
            "Q5.1",
            "Q5",
            "A successful provider response must have HTTP status 200.",
            spec,
            "accepts only a provider `200`",
        )
        add(
            "Q5.2",
            "Q5",
            "The successful response body must be valid UTF-8.",
            spec,
            "UTF-8 JSON",
        )
        add(
            "Q5.3",
            "Q5",
            "The successful response body must parse as valid JSON.",
            spec,
            "UTF-8 JSON",
        )
        add(
            "Q5.4",
            "Q5",
            "The JSON object must contain a nonempty choices list.",
            spec,
            "an object with a `choices` list that is not empty",
        )
        add(
            "Q5.5",
            "Q5",
            "The first choice must contain a message whose content is a string.",
            spec,
            "whose first item is an object with a `message` object whose `content` is a string",
            "A generic valid shape does not specify the first-choice/message/content requirement.",
        )
        add(
            "Q5.6",
            "Q5",
            "The content must be nonempty after stripping leading and trailing whitespace.",
            spec,
            "after removing leading and trailing whitespace as Python's `str.strip()` does, is not empty",
        )
        add(
            "Q5.7",
            "Q5",
            "The content need not equal OK.",
            spec,
            "The content need not be exactly `OK`",
        )
        add(
            "Q5.8",
            "Q5",
            "The provider Content-Type header is not used as a success criterion.",
            spec,
            "The app does not check the provider's `Content-Type` header",
        )
        add(
            "Q5.9",
            "Q5",
            "The response body may not exceed 65,536 bytes.",
            spec,
            "reads at most 65,536 bytes of the response body",
        )
        add(
            "Q6.1",
            "Q6",
            "Environment proxy settings are bypassed; the opener uses no proxy.",
            write,
            message,
            "No proxy includes environment proxies; exact handler spelling is not required.",
        )
        add("Q6.2", "Q6", "The request omits the User-Agent header.", write, message)
        key = {
            "run_id": run_id,
            "prepared_at_utc": datetime.now(timezone.utc).isoformat(),
            "history_sha256": run.digest(folder / "handoff-history.txt"),
            "source_policy": "Only supplied history; closing handoff and experimenter final check excluded.",
            "questions": [
                {
                    "id": q["id"],
                    "status": "scored",
                    "fact_ids": [f["id"] for f in facts if f["question_id"] == q["id"]],
                }
                for q in run.QUESTIONS
            ],
            "facts": facts,
        }
        run.write_json(run.PRIVATE / "answer-keys" / f"{run_id}.json", key)
        print(
            run_id,
            len(facts),
            "expected facts; source evidence keyed before handoffs",
            flush=True,
        )
    run.write_json(
        ROOT / "keys-prepared.json",
        {
            "at_utc": datetime.now(timezone.utc).isoformat(),
            "no_scored_handoffs_exist": True,
        },
    )


if __name__ == "__main__":
    main()
