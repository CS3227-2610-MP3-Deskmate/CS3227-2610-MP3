"""Native Codex app-server adapter; logs RPC evidence, never credential files."""

import json
import queue
import subprocess
import threading
import time
from pathlib import Path


def generate(executable, environment, cwd, system, model, prompt, schema, directory):
    """Run one fresh ephemeral thread and retain all visible RPC events."""
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    stderr_path = directory / "appserver-stderr.txt"
    normalized = []
    actual_model = None
    with (
        stderr_path.open("w", encoding="utf-8") as stderr,
        (directory / "appserver-rpc.jsonl").open("w", encoding="utf-8") as evidence,
    ):
        process = subprocess.Popen(
            [executable, "app-server", "--stdio"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=stderr,
            text=True,
            encoding="utf-8",
            errors="replace",
            cwd=cwd,
            env=environment,
        )
        messages = queue.Queue()

        def collect():
            for line in process.stdout:
                if line.strip():
                    messages.put(line)
            messages.put(None)

        threading.Thread(target=collect, daemon=True).start()

        def send(message):
            evidence.write(
                json.dumps(
                    {"direction": "send", "message": message}, ensure_ascii=False
                )
                + "\n"
            )
            evidence.flush()
            process.stdin.write(json.dumps(message, ensure_ascii=True) + "\n")
            process.stdin.flush()

        def get_event(deadline):
            line = messages.get(timeout=max(0.1, deadline - time.monotonic()))
            if line is None:
                raise RuntimeError("Native app-server exited before completion")
            event = json.loads(line)
            evidence.write(
                json.dumps(
                    {"direction": "receive", "message": event}, ensure_ascii=False
                )
                + "\n"
            )
            evidence.flush()
            if "method" in event and "id" in event:
                normalized.append(
                    {
                        "type": "item.completed",
                        "item": {
                            "type": "blocked_native_request",
                            "method": event["method"],
                        },
                    }
                )
                send(
                    {
                        "id": event["id"],
                        "error": {
                            "code": -32601,
                            "message": "Native tools are forbidden in this experiment",
                        },
                    }
                )
            return event

        def request(number, method, params):
            send({"id": number, "method": method, "params": params})
            deadline = time.monotonic() + 60
            while True:
                event = get_event(deadline)
                if event.get("id") == number and "method" not in event:
                    if event.get("error"):
                        raise RuntimeError(json.dumps(event["error"]))
                    return event.get("result", {})

        status = 1
        try:
            request(
                1,
                "initialize",
                {
                    "clientInfo": {"name": "handoff-experiment", "version": "1"},
                    "capabilities": {"experimentalApi": True},
                },
            )
            send({"method": "initialized"})
            thread = request(
                2,
                "thread/start",
                {
                    "model": model,
                    "ephemeral": True,
                    "cwd": str(cwd),
                    "baseInstructions": system,
                    "developerInstructions": "",
                    "permissions": "experiment-text",
                    "approvalPolicy": "never",
                    "dynamicTools": [],
                },
            )
            thread_id = thread["thread"]["id"]
            actual_model = thread.get("model")
            normalized.append(
                {
                    "type": "thread.started",
                    "thread_id": thread_id,
                    "model": actual_model,
                }
            )
            params = {
                "threadId": thread_id,
                "input": [{"type": "text", "text": prompt}],
                "effort": "medium",
                "summary": "none",
            }
            if schema:
                params["outputSchema"] = schema
            request(3, "turn/start", params)
            deadline = time.monotonic() + 360
            while time.monotonic() < deadline:
                event = get_event(deadline)
                method = event.get("method", "")
                data = event.get("params", {})
                if method == "item/completed":
                    item = data.get("item", {})
                    kind = item.get("type")
                    if kind == "agentMessage":
                        normalized.append(
                            {
                                "type": "item.completed",
                                "item": {
                                    "type": "agent_message",
                                    "text": item.get("text", ""),
                                },
                            }
                        )
                    elif kind not in ["userMessage", "reasoning"]:
                        normalized.append(
                            {
                                "type": "item.completed",
                                "item": {"type": kind, "details": item},
                            }
                        )
                elif method == "error":
                    normalized.append({"type": "error", "message": json.dumps(data)})
                elif method == "turn/completed":
                    turn = data.get("turn", {})
                    status = 0 if turn.get("status") == "completed" else 1
                    normalized.append(
                        {
                            "type": "turn.completed" if status == 0 else "turn.failed",
                            "details": turn,
                        }
                    )
                    break
            else:
                raise TimeoutError("Native app-server turn timed out")
        except (RuntimeError, TimeoutError, queue.Empty) as error:
            normalized.append({"type": "error", "message": str(error)})
            status = 1
        finally:
            process.terminate()
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=10)
    return {
        "returncode": status,
        "stdout": "\n".join(
            json.dumps(event, ensure_ascii=False) for event in normalized
        )
        + "\n",
        "stderr": stderr_path.read_text(encoding="utf-8"),
        "actual_model": actual_model,
    }


if __name__ == "__main__":
    import run

    run.ensure_client_signin()
    directory = run.ROOT / "audits" / "appserver-receiver"
    prompt = (
        run.ROOT
        / "runs"
        / "practice-02"
        / "receivers"
        / "gpt-5.6-sol"
        / "prose"
        / "prompt.txt"
    ).read_text(encoding="utf-8")
    try:
        result = generate(
            run.CODEX,
            run.child_env(),
            run.EMPTY,
            run.SYSTEM,
            "gpt-5.6-sol",
            prompt,
            None,
            directory,
        )
        (directory / "normalized-events.jsonl").write_text(
            result["stdout"], encoding="utf-8"
        )
        print(result["stdout"])
        print("Exit:", result["returncode"])
    finally:
        run.cleanup_client_signin()
