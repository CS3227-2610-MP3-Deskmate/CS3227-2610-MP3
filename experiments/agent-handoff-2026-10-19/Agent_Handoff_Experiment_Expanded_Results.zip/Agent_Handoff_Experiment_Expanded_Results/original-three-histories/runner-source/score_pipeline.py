"""Freeze source-evidenced keys before scored handoff generation."""

import atexit
from datetime import datetime, timezone

import analyse
import prepare_keys
import run

atexit.register(run.cleanup_client_signin)
prepare_keys.main()
for number in range(1, 4):
    run_id = f"coding-{number:02}"
    keypath = run.PRIVATE / "answer-keys" / f"{run_id}.json"
    key = run.read_json(keypath)
    history = run.read_json(run.ROOT / "runs" / run_id / "handoff-history.json")
    notes = [
        (i, e["content"]["message"])
        for i, e in enumerate(history)
        if e["role"] == "assistant"
        and "urllib cannot strictly bound DNS/connect/TLS time in total"
        in e["content"]["message"]
    ]
    for i, note in notes:
        key["facts"].append(
            {
                "id": "Q3.8",
                "question_id": "Q3",
                "claim": "The agent explicitly warns that urllib cannot strictly bound combined DNS/connect/TLS time; checks around open do not prove a hard production total deadline.",
                "source_evidence": [
                    {
                        "entry": i,
                        "excerpt": "urllib cannot strictly bound DNS/connect/TLS time in total",
                    }
                ],
                "interpretation": "This is a specific recorded transport limitation, distinct from merely not running production timing tests.",
            }
        )
        next(q for q in key["questions"] if q["id"] == "Q3")["fact_ids"].append("Q3.8")
    next(f for f in key["facts"] if f["id"] == "Q4.1")["interpretation"] = (
        "Credit the recorded 10-second deadline/budget; this does not assert a proven hard real-world upper bound."
    )
    for fact in key["facts"]:
        for evidence in fact["source_evidence"]:
            assert any(
                evidence["excerpt"] in text
                for text in analyse.flat_strings(history[evidence["entry"]])
            ), (run_id, fact["id"])
    run.write_json(keypath, key)
    print("VALIDATED", run_id, len(key["facts"]), "facts", flush=True)
run.freeze()
run.write_json(
    run.ROOT / "frozen-at.json",
    {
        "at_utc": datetime.now(timezone.utc).isoformat(),
        "all_keys_validated": True,
        "scored_handoffs_started": False,
    },
)
status = run.read_json(run.ROOT / "STATUS.json")
status["stage"] = "Questions, keys and prompts frozen; scored handoffs in progress"
run.write_json(run.ROOT / "STATUS.json", status)
run.generate_all("handoffs")
status["stage"] = "24 scored handoffs saved; Opus receiving quizzes in progress"
run.write_json(run.ROOT / "STATUS.json", status)
run.generate_all("receivers")
status["stage"] = (
    "24 scored handoffs and 24 Opus quizzes complete; fact-by-fact experimenter review pending"
)
run.write_json(run.ROOT / "STATUS.json", status)
print("ALL SCORED OUTPUTS SAVED. No quality retries; practice excluded.", flush=True)
