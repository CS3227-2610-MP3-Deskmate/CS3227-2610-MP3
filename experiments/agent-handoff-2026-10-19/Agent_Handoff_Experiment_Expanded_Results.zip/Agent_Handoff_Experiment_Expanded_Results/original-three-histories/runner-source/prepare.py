"""Prepare immutable inputs for the isolated handoff experiment."""

import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = Path(r"{REPOSITORY_ROOT}")
START = "6b8af72ee1ffe9527f3ed53bdeea5190c8f487f9"
REFERENCE = "a83fd52a72eaff7f9b262ba4e0bff30b144a479c"


def export(commit, source, destination):
    result = subprocess.run(
        ["git", "-C", str(REPO), "show", f"{commit}:{source}"],
        capture_output=True,
        check=True,
    )
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(result.stdout)


if __name__ == "__main__":
    for name, commit in [("baseline", START), ("reference", REFERENCE)]:
        export(commit, "src/deskmate/llm.py", ROOT / "private" / name / "llm.py")
        export(
            START,
            "workflow/specs/ai/llm-health.md",
            ROOT / "private" / name / "llm-health.md",
        )
    manifest = {"starting_commit": START, "reference_commit": REFERENCE, "exports": {}}
    for path in sorted((ROOT / "private").glob("*/llm*")):
        manifest["exports"][str(path.relative_to(ROOT))] = hashlib.sha256(
            path.read_bytes()
        ).hexdigest()
    (ROOT / "private" / "source-manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(manifest, indent=2))
