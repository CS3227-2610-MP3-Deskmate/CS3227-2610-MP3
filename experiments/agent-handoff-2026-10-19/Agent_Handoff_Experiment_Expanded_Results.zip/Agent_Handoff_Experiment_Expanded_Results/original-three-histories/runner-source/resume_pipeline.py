"""Generate all conditions from corrected, frozen visible transcripts."""
import atexit
import run

atexit.register(run.cleanup_client_signin)
run.verify_freeze()
run.generate_all('handoffs')
status = run.read_json(run.ROOT/'STATUS.json')
status['stage'] = 'All 24 corrected-transcript handoffs saved; fixed Opus receiving quizzes in progress'
run.write_json(run.ROOT/'STATUS.json',status)
run.generate_all('receivers')
status['stage'] = '24 handoffs and 24 Opus quizzes saved; experimenter fact review in progress'
run.write_json(run.ROOT/'STATUS.json',status)
print('ALL FINAL SCORED OUTPUTS SAVED; preliminary transcript-v1 outputs excluded.',flush=True)