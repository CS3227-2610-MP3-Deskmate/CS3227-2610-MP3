"""Validate completed results and build an explicit, credential-free shareable bundle."""

import json
import shutil
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import analyse
import audit_evidence
import run


def main():
    audit_evidence.main()
    audit = run.read_json(run.ROOT / "cli-audit.json")
    assert audit["completed_scored_calls_audited"] == 66, (
        "Expect 18 coding + 24 handoff + 24 receiving calls"
    )
    analyse.main()
    out = analyse.OUT
    shutil.copyfile(run.ROOT / "cli-audit.json", out / "cli-audit.json")
    setup = out / "test-setup"
    setup.mkdir(exist_ok=True)
    for name in ["llm.py", "llm-health.md", "test_probe.py"]:
        shutil.copyfile(run.PRIVATE / "baseline" / name, setup / name)
    shutil.copyfile(
        run.PRIVATE / "validation" / "summary.json", setup / "validation-summary.json"
    )
    code = out / "runner-source"
    code.mkdir(exist_ok=True)
    for name in [
        "run.py",
        "appserver_backend.py",
        "prepare.py",
        "prepare_keys.py",
        "score_pipeline.py",
        "repair_transcripts.py",
        "resume_pipeline.py",
        "analyse.py",
        "audit_evidence.py",
        "format_review.py",
        "finalize.py",
    ]:
        shutil.copyfile(run.ROOT / name, code / name)
    lengths = []
    for n in range(1, 4):
        run_id = f"coding-{n:02}"
        p = run.ROOT / "runs" / run_id / "handoff-history.txt"
        text = p.read_text(encoding="utf-8")
        lengths.append(
            {
                "run_id": run_id,
                "characters": len(text),
                "utf8_bytes": len(p.read_bytes()),
                "whitespace_words": len(text.split()),
                "history_sha256": run.digest(p),
                "patch_sha256": run.digest(run.ROOT / "runs" / run_id / "repair.patch"),
            }
        )
    run.write_json(out / "source-lengths.json", lengths)
    ET.parse(out / "comparison.svg")
    scores = run.read_json(out / "fact-scores.json")
    assert len(scores) == 656
    assert (
        len(
            {
                (r["run_id"], r["handoff_model"], r["format"], r["fact_id"])
                for r in scores
            }
        )
        == 656
    )
    assert {r["outcome"] for r in scores} <= {"correct", "not stated", "wrong"}
    # The native sign-in link must have been removed after inference, and is never exported.
    assert not (run.PRIVATE / "client-home" / "auth.json").exists(), (
        "Temporary native sign-in path must be cleaned first"
    )
    status = run.read_json(run.ROOT / "STATUS.json")
    status.update(
        {
            "stage": "Complete: three coding histories, 24 final handoffs, 24 fixed-Opus quizzes, 656 reviewed fact rows",
            "completed_at_utc": datetime.now(timezone.utc).isoformat(),
            "scored_runs": 3,
            "scored_handoffs": 24,
            "scored_receiving_quizzes": 24,
            "scored_fact_rows": 656,
            "temporary_signin_link_removed": True,
            "native_tool_events_recorded": 0,
            "incomplete_final_client_audits": 0,
            "preliminary_transcript_v1_handoffs_excluded": 8,
            "results": "final-results/report.html",
        }
    )
    run.write_json(run.ROOT / "STATUS.json", status)
    run.write_json(out / "STATUS.json", status)
    (out / "README.txt").write_text(
        "AGENT HANDOFF EXPERIMENT\n\nOpen report.html for the findings and chart. All final source histories, patches,\nhandoffs and receiving answers are under evidence/. Frozen prompts, model\nsettings, questions and answer keys are under frozen/. fact-scores.json records\nevery semantic judgment; judgments were assigned by the Codex assistant in the\nexperimenter role, with model and format visible, without an independent human\ngrader.\n\nThree fresh Opus 5.5 coding histories; four handoff models; paired formats;\nOpus 5.5 receiver. All practice runs are excluded. Eight preliminary handoffs\nwere also excluded because transcript normalization moved JSON fences; see\ntranscript-revision.json. No semantic expected fact or question was changed.\n\nThis folder contains an explicit safe export. It excludes native credential\nfiles, client-home, private reference repair and raw account/client state.\nAll raw attempts remain in the parent experiment folder. runner-source/ is an\nauditable code copy; the original working runner and native-client setup are\nin {EXPERIMENT_ROOT}. Use the existing\nrepository .venv Python. The runner requires existing subscription sign-ins\nand the pinned, already-installed Docker image; it installs nothing. Future\nservice aliases/availability may differ. Do not rerun inference into existing\ncondition directories or overwrite the frozen keys.\n\nWord counts use str.split and include labels. Results are descriptive, share\nthree histories and do not constitute a general frontier-model ranking.\nOpenAI retained tool schemas under the user-accepted audited-session exception.\nNo native tool calls were recorded; this is a client-visible audit, not proof\nof full backend isolation.\n",
        encoding="utf-8",
    )
    files = sorted(p for p in out.rglob("*") if p.is_file())
    for path in files:
        assert not path.is_symlink()
        assert path.name.lower() not in {"auth.json", ".env"}
        assert "client-home" not in path.parts
    run.write_json(
        out / "artifact-sha256.json",
        {
            str(p.relative_to(out)): run.digest(p)
            for p in files
            if p.name != "artifact-sha256.json"
        },
    )
    zip_path = run.ROOT / "Agent_Handoff_Experiment_Results.zip"
    with ZipFile(zip_path, "w", compression=ZIP_DEFLATED) as archive:
        for path in sorted(p for p in out.rglob("*") if p.is_file()):
            archive.write(
                path,
                arcname=Path("Agent_Handoff_Experiment_Results")
                / path.relative_to(out),
            )
    with ZipFile(zip_path) as archive:
        assert archive.testzip() is None
        assert all(
            not name.lower().endswith("/auth.json") and "/client-home/" not in name
            for name in archive.namelist()
        )
    print(
        json.dumps(
            {
                "report": str(out / "report.html"),
                "chart": str(out / "comparison.svg"),
                "zip": str(zip_path),
                "files": len(files),
                "fact_rows": len(scores),
                "sha256": run.digest(zip_path),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
