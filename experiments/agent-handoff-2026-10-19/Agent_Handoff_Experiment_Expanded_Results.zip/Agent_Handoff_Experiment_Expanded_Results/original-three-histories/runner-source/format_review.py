"""Audit assigned formats without modifying or regenerating any handoff."""

import re

import run


def main():
    rows = []
    for n in range(1, 4):
        run_id = f"coding-{n:02}"
        for model in run.MODELS:
            for fmt in run.FORMATS:
                path = (
                    run.ROOT / "runs" / run_id / "handoffs" / model / fmt / "output.txt"
                )
                if not path.exists():
                    continue
                text = path.read_text(encoding="utf-8")
                flags = []
                if fmt == "prose":
                    bullets = [
                        line
                        for line in text.splitlines()
                        if re.match(r"^\s*(?:[-*+]\s+|\d+[.)]\s+)", line)
                    ]
                    headings = [
                        line
                        for line in text.splitlines()
                        if re.match(r"^\s*#{1,6}\s+", line)
                    ]
                    if bullets:
                        flags.append(
                            {
                                "kind": "prose contains bullet/number list",
                                "evidence": bullets,
                            }
                        )
                    if headings:
                        flags.append(
                            {
                                "kind": "prose contains Markdown heading",
                                "evidence": headings,
                            }
                        )
                rows.append(
                    {
                        "run_id": run_id,
                        "handoff_model": model,
                        "assigned_format": fmt,
                        "word_count": len(text.split()),
                        "within_200_words": len(text.split()) <= 200,
                        "clear_format_flags": flags,
                    }
                )
    run.write_json(
        run.ROOT / "format-review.json",
        {
            "rule": "Flag unambiguous Markdown lists/headings in assigned prose; inline labels alone are not classified as headings. Checklist label presence is reviewed manually with false-claim review. These diagnostics do not change primary counts or regenerate outputs.",
            "rows": rows,
        },
    )
    print(
        "Format audit:",
        len(rows),
        "outputs;",
        sum(bool(r["clear_format_flags"]) for r in rows),
        "with unambiguous prose violations",
    )


if __name__ == "__main__":
    main()
