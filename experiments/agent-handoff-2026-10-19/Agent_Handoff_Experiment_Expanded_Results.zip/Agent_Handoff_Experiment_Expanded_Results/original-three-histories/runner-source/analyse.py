"""Generate descriptive results from frozen keys and experimenter judgments."""

import html
import json
import shutil
from collections import Counter, defaultdict

import run

ROOT = run.ROOT
OUT = ROOT / "final-results"
LABELS = {
    "gpt-5.6-sol": "Sol 5.6",
    "gpt-5.6-luna": "Luna 5.6",
    "claude-opus-5-5": "Opus 5.5",
    "claude-sonnet-5-5": "Sonnet 5.5",
}
OUTCOMES = ["correct", "not stated", "wrong"]
COLORS = {"correct": "#26734d", "not stated": "#d9dee5", "wrong": "#c43d3d"}


def load(path):
    return run.read_json(path)


def save(name, value):
    run.write_json(OUT / name, value)


def cell_id(run_id, model, fmt):
    return "|".join([run_id, model, fmt])


def flat_strings(value):
    if isinstance(value, str):
        return [value]
    if isinstance(value, dict):
        return [text for item in value.values() for text in flat_strings(item)]
    if isinstance(value, list):
        return [text for item in value for text in flat_strings(item)]
    return []


def table(headers, rows):
    cells = "".join(
        "<tr>"
        + "".join(
            "<td>" + html.escape("N/A" if x is None else str(x)) + "</td>" for x in row
        )
        + "</tr>"
        for row in rows
    )
    return (
        "<table><thead><tr>"
        + "".join("<th>" + html.escape(h) + "</th>" for h in headers)
        + "</tr></thead><tbody>"
        + cells
        + "</tbody></table>"
    )


def chart(metrics):
    svg = [
        '<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="550" viewBox="0 0 1000 550" role="img" aria-labelledby="title desc">',
        '<title id="title">Recoverable facts by handoff model and format</title>',
        '<desc id="desc">Stacked bars show correct, omitted and wrong expected facts. All bars share three coding histories, not independent replications.</desc>',
        '<rect width="1000" height="550" fill="white"/>',
        '<g font-family="Arial,sans-serif" fill="#17202a">',
        '<text x="30" y="35" font-size="23" font-weight="bold">Facts recovered by the fixed Opus receiver</text>',
        '<text x="30" y="61" font-size="15">One task · three histories · one handoff per model, format and history</text>',
    ]
    for tick in range(0, 101, 20):
        x = 220 + tick * 5.8
        svg.append(
            f'<line x1="{x}" y1="95" x2="{x}" y2="455" stroke="#e4e7ec"/><text x="{x}" y="477" text-anchor="middle" font-size="13">{tick}%</text>'
        )
    for index, item in enumerate(metrics):
        y = 100 + index * 43
        label = LABELS[item["handoff_model"]] + " / " + item["format"]
        svg.append(
            f'<text x="205" y="{y + 20}" text-anchor="end" font-size="15">{label}</text>'
        )
        x = 220.0
        for outcome in OUTCOMES:
            width = 580 * item[outcome] / item["denominator"]
            svg.append(
                f'<rect x="{x:.2f}" y="{y}" width="{width:.2f}" height="29" fill="{COLORS[outcome]}"/>'
            )
            x += width
        svg.append(
            f'<text x="815" y="{y + 20}" font-size="14">{item["correct"]}/{item["denominator"]} correct</text>'
        )
    for i, outcome in enumerate(OUTCOMES):
        x = 225 + i * 205
        svg.append(
            f'<rect x="{x}" y="505" width="18" height="18" fill="{COLORS[outcome]}"/><text x="{x + 25}" y="520" font-size="15">{outcome.capitalize()}</text>'
        )
    svg.extend(["</g>", "</svg>"])
    return "\n".join(svg)


def main():
    run.verify_freeze()
    import format_review

    format_review.main()
    OUT.mkdir(exist_ok=True)
    judgments = load(ROOT / "judgments.json")
    rows, words, paired, support_flags = [], [], [], []
    expected_cells = set()
    for number in range(1, 4):
        run_id = f"coding-{number:02}"
        source_dir = ROOT / "runs" / run_id
        key = load(ROOT / "frozen" / f"{run_id}-answer-key.json")
        assert key["history_sha256"] == run.digest(source_dir / "handoff-history.txt")
        history = load(source_dir / "handoff-history.json")
        for fact in key["facts"]:
            assert fact["source_evidence"]
            for evidence in fact["source_evidence"]:
                assert any(
                    evidence["excerpt"] in value
                    for value in flat_strings(history[evidence["entry"]])
                ), (run_id, fact["id"], evidence)
        for model in run.MODELS:
            for fmt in run.FORMATS:
                identifier = cell_id(run_id, model, fmt)
                expected_cells.add(identifier)
                annotation = judgments["cells"][identifier]
                correct = set(annotation["correct"])
                wrong = annotation.get("wrong", {})
                all_ids = {fact["id"] for fact in key["facts"]}
                assert (
                    correct <= all_ids
                    and set(wrong) <= all_ids
                    and not (correct & set(wrong))
                )
                handoff_dir = source_dir / "handoffs" / model / fmt
                receiver_dir = source_dir / "receivers" / model / fmt
                answers = {
                    a["id"]: a for a in load(receiver_dir / "answers.json")["answers"]
                }
                handoff = (handoff_dir / "output.txt").read_text(encoding="utf-8")
                word_count = len(handoff.split())
                assert (
                    word_count == load(handoff_dir / "format-check.json")["word_count"]
                )
                words.append(
                    {
                        "run_id": run_id,
                        "handoff_model": model,
                        "format": fmt,
                        "word_count": word_count,
                        "within_200_words": word_count <= 200,
                    }
                )
                validation = load(receiver_dir / "answer-validation.json")
                for unmatched in validation["unmatched_quotes"]:
                    support_flags.append(
                        {"cell": identifier, "kind": "unmatched quote", **unmatched}
                    )
                for flag in annotation.get("support_flags", []):
                    support_flags.append({"cell": identifier, **flag})
                for fact in key["facts"]:
                    evidence_ids = annotation.get("evidence_questions", {}).get(
                        fact["id"], [fact["question_id"]]
                    )
                    selected_answers = [answers[q] for q in evidence_ids]
                    answer = {
                        "answer": "\n".join(
                            (f"[{q}] " if q != fact["question_id"] else "")
                            + answers[q]["answer"]
                            for q in evidence_ids
                        ),
                        "quotes": [
                            quote
                            for value in selected_answers
                            for quote in value["quotes"]
                        ],
                    }
                    outcome = (
                        "correct"
                        if fact["id"] in correct
                        else "wrong"
                        if fact["id"] in wrong
                        else "not stated"
                    )
                    reason = (
                        "Expected semantic claim is present in the answer or its supporting quotes."
                        if outcome == "correct"
                        else wrong[fact["id"]]
                        if outcome == "wrong"
                        else "Expected claim is absent from the full quiz; absence is not scored wrong."
                    )
                    reason = annotation.get("fact_reasons", {}).get(fact["id"], reason)
                    rows.append(
                        {
                            "run_id": run_id,
                            "handoff_model": model,
                            "format": fmt,
                            "question_id": fact["question_id"],
                            "fact_id": fact["id"],
                            "expected_fact": fact["claim"],
                            "source_evidence": fact["source_evidence"],
                            "receiver_evidence_question_ids": evidence_ids,
                            "receiver_answer": answer["answer"],
                            "supporting_quotes": answer["quotes"],
                            "outcome": outcome,
                            "reason": reason,
                        }
                    )
            pair_words = {
                w["format"]: w["word_count"]
                for w in words
                if w["run_id"] == run_id and w["handoff_model"] == model
            }
            pair_rows = [
                r for r in rows if r["run_id"] == run_id and r["handoff_model"] == model
            ]
            counts = {
                fmt: Counter(r["outcome"] for r in pair_rows if r["format"] == fmt)
                for fmt in run.FORMATS
            }
            denominator = len(key["facts"])
            paired.append(
                {
                    "run_id": run_id,
                    "handoff_model": model,
                    "denominator_per_format": denominator,
                    "prose": dict(counts["prose"]),
                    "checklist": dict(counts["checklist"]),
                    "checklist_minus_prose_correct": counts["checklist"]["correct"]
                    - counts["prose"]["correct"],
                    "both_within_word_limit": all(
                        n <= 200 for n in pair_words.values()
                    ),
                }
            )
    assert set(judgments["cells"]) == expected_cells
    group = defaultdict(Counter)
    for row in rows:
        group[(row["handoff_model"], row["format"], row["question_id"])][
            row["outcome"]
        ] += 1
    question_metrics = []
    for (model, fmt, question), counts in sorted(group.items()):
        question_metrics.append(
            {
                "handoff_model": model,
                "format": fmt,
                "question_id": question,
                **{name: counts[name] for name in OUTCOMES},
                "denominator": sum(counts.values()),
            }
        )
    metrics, sensitivity = [], []
    for model in run.MODELS:
        for fmt in run.FORMATS:
            selected = [
                r for r in rows if r["handoff_model"] == model and r["format"] == fmt
            ]
            counts = Counter(r["outcome"] for r in selected)
            metrics.append(
                {
                    "handoff_model": model,
                    "format": fmt,
                    **{name: counts[name] for name in OUTCOMES},
                    "denominator": len(selected),
                    "correct_percent": round(
                        100 * counts["correct"] / len(selected), 2
                    ),
                }
            )
            compliant = {
                p["run_id"]
                for p in paired
                if p["handoff_model"] == model and p["both_within_word_limit"]
            }
            chosen = [r for r in selected if r["run_id"] in compliant]
            counters = Counter(r["outcome"] for r in chosen)
            sensitivity.append(
                {
                    "handoff_model": model,
                    "format": fmt,
                    "compliant_paired_histories": sorted(compliant),
                    **{name: counters[name] for name in OUTCOMES},
                    "denominator": len(chosen),
                    "correct_percent": round(100 * counters["correct"] / len(chosen), 2)
                    if chosen
                    else None,
                }
            )
    calls = []
    for number in range(1, 4):
        base = ROOT / "runs" / f"coding-{number:02}"
        for stage in ["raw", "handoffs", "receivers"]:
            for path in (base / stage).rglob("metadata.json"):
                meta = load(path)
                calls.append(
                    {
                        "path": str(path.relative_to(ROOT)),
                        **{
                            name: meta.get(name)
                            for name in [
                                "requested_model",
                                "actual_model_ids_reported",
                                "started_at_utc",
                                "exit_code",
                                "native_tool_events",
                                "audit_flags",
                                "prompt_sha256",
                                "output_sha256",
                            ]
                        },
                    }
                )
    unique_calls = {
        (c["requested_model"], c["started_at_utc"], c["prompt_sha256"]): c
        for c in calls
    }
    calls = list(unique_calls.values())
    audit = {
        "scored_call_attempts": len(calls),
        "nonzero_exit_attempts": sum(c["exit_code"] != 0 for c in calls),
        "native_tool_events_recorded": sum(
            len(c["native_tool_events"] or []) for c in calls
        ),
        "all_three_coding_runs_passed": all(
            load(ROOT / "runs" / f"coding-{n:02}" / "audit.json")[
                "final_test_exit_code"
            ]
            == 0
            for n in range(1, 4)
        ),
        "openai_tool_availability_exception": load(ROOT / "protocol.json")[
            "isolation_exception"
        ],
        "snapshot_limitation": "Pinned public model IDs and native-reported model names; immutable service snapshots are not guaranteed.",
        "calls": calls,
    }
    save("fact-scores.json", rows)
    save("model-format-results.json", metrics)
    save("question-results.json", question_metrics)
    save("paired-results.json", paired)
    save("word-counts.json", words)
    save("compliant-pair-sensitivity.json", sensitivity)
    save(
        "observations.json",
        {
            "manual_review": judgments.get("observations", []),
            "support_flags": support_flags,
        },
    )
    assert audit["native_tool_events_recorded"] == 0
    save("format-review.json", load(ROOT / "format-review.json"))
    for name in [
        "transcript-revision.json",
        "frozen-at.json",
        "scored-started.json",
        "keys-prepared.json",
    ]:
        save(name, load(ROOT / name))
    save("audit-summary.json", audit)
    save("judgments.json", judgments)
    (OUT / "comparison.svg").write_text(chart(metrics), encoding="utf-8")
    for number in range(1, 4):
        run_id = f"coding-{number:02}"
        src = ROOT / "runs" / run_id
        target = OUT / "evidence" / run_id
        target.mkdir(parents=True, exist_ok=True)
        for name in [
            "handoff-history.txt",
            "handoff-history.json",
            "repair.patch",
            "audit.json",
        ]:
            shutil.copyfile(src / name, target / name)
        for model in run.MODELS:
            for fmt in run.FORMATS:
                directory = target / model / fmt
                directory.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(
                    src / "handoffs" / model / fmt / "output.txt",
                    directory / "handoff.txt",
                )
                shutil.copyfile(
                    src / "receivers" / model / fmt / "answers.json",
                    directory / "answers.json",
                )
    for path in (ROOT / "frozen").glob("*.json"):
        directory = OUT / "frozen"
        directory.mkdir(exist_ok=True)
        shutil.copyfile(path, directory / path.name)
    settings = load(ROOT / "pre-scored-settings.json")
    save("study-settings.json", settings)
    example = []
    for fmt in run.FORMATS:
        example.append(
            fmt.upper()
            + "\n"
            + (
                ROOT
                / "runs"
                / "coding-01"
                / "handoffs"
                / "gpt-5.6-sol"
                / fmt
                / "output.txt"
            ).read_text(encoding="utf-8")
        )
    (OUT / "handoff-example.txt").write_text("\n\n".join(example), encoding="utf-8")
    findings = load(ROOT / "report-findings.json")
    summary_table = table(
        [
            "Handoff model",
            "Format",
            "Correct",
            "Not stated",
            "Wrong",
            "Expected facts",
            "Correct %",
        ],
        [
            [
                LABELS[m["handoff_model"]],
                m["format"],
                m["correct"],
                m["not stated"],
                m["wrong"],
                m["denominator"],
                m["correct_percent"],
            ]
            for m in metrics
        ],
    )
    question_table = table(
        [
            "Model",
            "Format",
            "Question",
            "Correct",
            "Not stated",
            "Wrong",
            "Denominator",
        ],
        [
            [
                LABELS[m["handoff_model"]],
                m["format"],
                m["question_id"],
                m["correct"],
                m["not stated"],
                m["wrong"],
                m["denominator"],
            ]
            for m in question_metrics
        ],
    )
    words_table = table(
        ["History", "Model", "Format", "Words", "Within 200"],
        [
            [
                w["run_id"],
                LABELS[w["handoff_model"]],
                w["format"],
                w["word_count"],
                w["within_200_words"],
            ]
            for w in words
        ],
    )
    pairs_table = table(
        [
            "History",
            "Model",
            "Prose correct",
            "Checklist correct",
            "Checklist − prose",
            "Both within 200",
        ],
        [
            [
                p["run_id"],
                LABELS[p["handoff_model"]],
                p["prose"].get("correct", 0),
                p["checklist"].get("correct", 0),
                p["checklist_minus_prose_correct"],
                p["both_within_word_limit"],
            ]
            for p in paired
        ],
    )
    sensitivity_table = table(
        ["Model", "Format", "Compliant pairs", "Correct", "Denominator", "Correct %"],
        [
            [
                LABELS[s["handoff_model"]],
                s["format"],
                len(s["compliant_paired_histories"]),
                s["correct"],
                s["denominator"],
                s["correct_percent"],
            ]
            for s in sensitivity
        ],
    )
    narrative = "".join("<p>" + html.escape(p) + "</p>" for p in findings["paragraphs"])
    example_html = "".join(
        "<h3>"
        + html.escape(fmt)
        + "</h3><pre>"
        + html.escape(
            (
                OUT / "evidence" / "coding-01" / "gpt-5.6-sol" / fmt / "handoff.txt"
            ).read_text(encoding="utf-8")
        )
        + "</pre>"
        for fmt in run.FORMATS
    )
    observations = "".join(
        "<li>"
        + html.escape(o.get("summary", json.dumps(o, ensure_ascii=False)))
        + "</li>"
        for o in judgments.get("observations", [])
    )
    document = """<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Agent handoff experiment</title><style>body{max-width:1100px;margin:36px auto;padding:0 22px;font:17px/1.55 system-ui,sans-serif;color:#17202a}h1,h2,h3{line-height:1.2}table{border-collapse:collapse;width:100%;font-size:14px;margin:20px 0}td,th{border:1px solid #d9dee5;padding:7px;text-align:left}th{background:#eef2f6}tr:nth-child(even){background:#fafbfc}pre{white-space:pre-wrap;background:#f5f7f9;padding:18px;font:15px/1.55 system-ui}img{max-width:100%;height:auto}.note{border-left:4px solid #c43d3d;padding-left:16px}a{color:#165a97}</style><h1>Prose and checklist handoffs</h1>"""
    document += "<p>Completed 19 October 2026. Three fresh Opus 5.5 coding histories × four handoff models × two formats = 24 handoffs and 24 separate Opus 5.5 receiving quizzes. Practice excluded.</p>"
    document += (
        narrative
        + '<img src="comparison.svg" alt="Stacked comparison of recovered, omitted and wrong facts"><h2>Descriptive totals</h2>'
        + summary_table
    )
    document += (
        "<p>Each expected fact receives one label: correct, not stated, or wrong. Supporting quotes also count as receiver content. Facts explicitly stated anywhere in the six-answer response receive credit; topic counts follow the frozen key, and cross-question evidence locations are recorded. This operational clarification was made during unblinded review, rather than preregistered as a separate analysis. Facts missing from the source would be N/A, not loss. These totals reuse three source histories; facts are not independent experimental replications.</p><h2>Paired history results</h2>"
        + pairs_table
    )
    document += (
        "<h2>Word counts and sensitivity</h2><p>Words are whitespace-delimited, including labels. No overlength output was trimmed or regenerated. Sensitivity uses histories where both formats for that model stayed within 200 words.</p>"
        + words_table
        + sensitivity_table
    )
    document += (
        "<h2>Per-question results</h2><p>Q1 changed files; Q2 checks and outcomes; Q3 verification limits; Q4 total timeout reasoning and implementation; Q5 successful provider responses; Q6 proxies and headers. The frozen files contain exact wording and every evidence-based expected fact.</p>"
        + question_table
    )
    document += (
        "<h2>Concrete example</h2><p>coding-01 / Sol 5.6, both formats. This example selection was recorded before scored coding; it was not chosen for an extreme result.</p>"
        + example_html
    )
    document += (
        "<h2>Separate claim observations</h2><ul>"
        + observations
        + '</ul><h2>Method and limitations</h2><p class="note">One task, three histories, one sample per cell and a fixed Opus decoder support a small descriptive comparison. They do not establish a general ranking of frontier models. Opus writes the source histories and receives the handoffs, which may favour its terminology. Medium effort is a within-model setting, not equal compute across providers.</p>'
    )
    document += "<p>The initial GPT-6.1 Sol and GPT-6 Luna requests were rejected by the installed ChatGPT subscription client. Verified accessible GPT-5.6 Sol/Luna were used for handoffs. At the user’s explicit request, coding and receiving changed to Opus 5.5 before scored runs because OpenAI calls had intermittent 429/capacity failures. Pinned settings: medium effort, default temperature (not exposed), Codex 0.147.0 and Claude Code 2.1.301. Subscription model aliases do not guarantee immutable backend snapshots.</p>"
    document += "<p>Fresh native sessions received only assigned evidence. Coding used a JSON read/write/test harness; continuations replayed the complete visible history. The closing handoff and experimenter-only final check were excluded. Only llm.py could be written. Tests ran in a pinned, offline, read-only, unprivileged Docker container. The starting version failed with 5 failures and 4 errors among 30 tests; the private reference and each completed repair passed all 30. These simulated module tests do not verify Django, production deployment, live provider service, or real DNS/TLS deadline behaviour.</p>"
    document += "<p>Claude sessions exposed no tools. OpenAI retained native tool schemas despite restrictions; the user accepted audited sessions and disclosure. No native tool use was recorded in the scored calls. The audit covers client-visible events and is not proof of complete backend isolation. Source files, handoffs and other model outputs were treated as data. Failed capacity attempts were preserved; unchanged inputs/settings were retried only for infrastructure failure, never output quality or length. A single JSON envelope with surrounding visible prose is parsed without discarding that prose or regenerating a response.</p>"
    document += "<p>Questions and expected facts were frozen after all coding histories and before scored handoffs. The handoff prompt requests a work summary, rather than explicitly enumerating the six quiz topics. Consequently, omissions—especially unchanged contract details—measure recoverability under this prompt. Fact labels were assigned by the Codex assistant running this session in the experimenter role, with model and format visible. There was no independent human grader. Inspect the fact rows and evidence before treating small differences as substantive.</p>"
    format_data = load(ROOT / "format-review.json")
    format_flags = [r for r in format_data["rows"] if r["clear_format_flags"]]
    document += "<h2>Transcript correction and format diagnostics</h2><p>Eight preliminary handoffs were completed before a transcript-export defect was noticed: separating JSON actions from surrounding Markdown fences made those fences appear empty. The batch was stopped, all preliminary outputs and one interrupted native request were preserved and excluded, and all 24 handoffs were regenerated after reconstructing original visible assistant output verbatim. The three coding inferences, expected semantic facts, questions, prompts, model settings and example selection were unchanged. Only transcript rendering and its recorded hashes changed. No receiving quizzes had started. This protocol correction occurred after preliminary outputs were seen and is disclosed to make that deviation reviewable.</p>"
    document += (
        "<p>Unambiguous prose list/heading violations: "
        + str(len(format_flags))
        + '. See <a href="format-review.json">format diagnostics</a> and <a href="transcript-revision.json">revision manifest</a>. Inline labels alone are not classified as headings. The pre-scored-settings flag describes its original role-freeze snapshot; current completion is reported here and in STATUS.json.</p>'
    )
    document += '<h2>Reviewable artifacts</h2><p><a href="fact-scores.json">Every fact judgment and source evidence</a> · <a href="question-results.json">Question counts</a> · <a href="observations.json">Claim and quote observations</a> · <a href="audit-summary.json">Audit summary</a> · <a href="study-settings.json">Pinned settings</a> · <a href="handoff-example.txt">Example text</a>. Frozen keys/prompts are in frozen/; all scored histories, patches, handoffs and receiver answers are in evidence/. Raw native transcripts and every failed practice/provider attempt remain in the parent experiment folder; credentials and native client-home are excluded from this shareable results folder.</p></html>'
    (OUT / "report.html").write_text(document, encoding="utf-8")
    save(
        "artifact-sha256.json",
        {
            str(p.relative_to(OUT)): run.digest(p)
            for p in OUT.rglob("*")
            if p.is_file() and p.name != "artifact-sha256.json"
        },
    )
    print(
        json.dumps(
            {
                "facts_scored": len(rows),
                "cells": len(expected_cells),
                "metrics": metrics,
                "word_limit_violations": sum(not w["within_200_words"] for w in words),
                "support_flags": len(support_flags),
                "audit": {k: v for k, v in audit.items() if k != "calls"},
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
