AGENT HANDOFF EXPERIMENT

Open report.html for the findings and chart. All final source histories, patches,
handoffs and receiving answers are under evidence/. Frozen prompts, model
settings, questions and answer keys are under frozen/. fact-scores.json records
every semantic judgment; judgments were assigned by the Codex assistant in the
experimenter role, with model and format visible, without an independent human
grader.

Three fresh Opus 5.5 coding histories; four handoff models; paired formats;
Opus 5.5 receiver. All practice runs are excluded. Eight preliminary handoffs
were also excluded because transcript normalization moved JSON fences; see
transcript-revision.json. No semantic expected fact or question was changed.

This folder contains an explicit safe export. It excludes native credential
files, client-home, private reference repair and raw account/client state.
All raw attempts remain in the parent experiment folder. runner-source/ is an
auditable code copy; the original working runner and native-client setup are
in {EXPERIMENT_ROOT}. Use the existing
repository .venv Python. The runner requires existing subscription sign-ins
and the pinned, already-installed Docker image; it installs nothing. Future
service aliases/availability may differ. Do not rerun inference into existing
condition directories or overwrite the frozen keys.

Word counts use str.split and include labels. Results are descriptive, share
three histories and do not constitute a general frontier-model ranking.
OpenAI retained tool schemas under the user-accepted audited-session exception.
No native tool calls were recorded; this is a client-visible audit, not proof
of full backend isolation.
