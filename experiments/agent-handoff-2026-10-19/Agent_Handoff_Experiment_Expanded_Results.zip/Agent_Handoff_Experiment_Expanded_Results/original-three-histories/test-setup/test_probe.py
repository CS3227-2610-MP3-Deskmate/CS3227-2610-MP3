"""Offline contract checks for llm.py; standard library only.

The module interface is the existing token_matches, probe, urlopen seam.
Tests cover this module, not Django routes or production TLS/DNS timing.
All credentials and response bodies below are synthetic test data.
"""

import contextlib
import http.client
import importlib.util
import io
import json
import os
import ssl
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from urllib.error import HTTPError, URLError
from urllib.request import Request

SPEC = importlib.util.spec_from_file_location(
    "probe_under_test", Path(__file__).with_name("llm.py")
)
llm = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(llm)
TOKEN = "synthetic-probe-token-for-offline-tests-123456"
KEY = "synthetic-provider-key-offline-only"
URL = "https://soclaas-api.comp.nus.edu.sg/v1/chat/completions"
EXPECTED = {
    "model": "llama3.1:8b",
    "messages": [
        {"role": "system", "content": "You are a health check. Reply with exactly OK."},
        {"role": "user", "content": "Reply with OK."},
    ],
    "max_tokens": 8,
    "temperature": 0,
    "stream": False,
}


def answer(content="OK"):
    return json.dumps({"choices": [{"message": {"content": content}}]}).encode()


class Clock:
    def __init__(self):
        self.now = 0.0

    def monotonic(self):
        return self.now


class Response:
    def __init__(
        self,
        body=None,
        status=200,
        clock=None,
        read_cost=0.0,
        chunk_size=None,
        error=None,
    ):
        self.body = answer() if body is None else body
        self.status = self.code = status
        self.reason = "synthetic"
        self.msg = "synthetic"
        self.headers = {"Content-Type": "text/plain"}
        self.pos = 0
        self.clock = clock
        self.read_cost = read_cost
        self.chunk_size = chunk_size
        self.error = error
        self.read_sizes = []
        self.timeouts = []
        self.closed = False
        self.fp = SimpleNamespace(
            raw=SimpleNamespace(_sock=SimpleNamespace(settimeout=self.timeouts.append))
        )

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def close(self):
        self.closed = True

    def info(self):
        return self.headers

    def read(self, size=-1):
        self.read_sizes.append(size)
        if self.error:
            raise self.error
        if self.clock:
            self.clock.now += self.read_cost
        if size < 0:
            size = len(self.body) - self.pos
        if self.chunk_size is not None:
            size = min(size, self.chunk_size)
        chunk = self.body[self.pos : self.pos + size]
        self.pos += len(chunk)
        return chunk

    read1 = read


class ProbeTests(unittest.TestCase):
    def setUp(self):
        self.environment = patch.dict(
            os.environ,
            {"SOC_LLM_API_KEY": KEY, "SOC_LLM_PROBE_TOKEN": TOKEN},
            clear=True,
        )
        self.environment.start()
        self.addCleanup(self.environment.stop)

    def probe_with(self, response=None, open_error=None, clock=None, open_cost=0.0):
        response = response or Response()
        calls = []

        def open_fake(request, timeout=None):
            calls.append((request, timeout))
            if clock:
                clock.now += open_cost
            if open_error:
                raise open_error
            return response

        with contextlib.ExitStack() as stack:
            stack.enter_context(patch.object(llm, "urlopen", open_fake))
            if clock:
                original = time.monotonic
                for name, value in list(vars(llm).items()):
                    if value is original:
                        stack.enter_context(patch.object(llm, name, clock.monotonic))
                stack.enter_context(patch("time.monotonic", clock.monotonic))
            result = llm.probe()
        return result, calls, response

    def test_valid_operator_token(self):
        self.assertTrue(llm.token_matches("Bearer " + TOKEN))

    def test_token_gate_exact_scheme_and_spacing(self):
        for header in [
            "",
            "bearer " + TOKEN,
            "Bearer  " + TOKEN,
            " Bearer " + TOKEN,
            "Bearer " + TOKEN + " ",
            "Basic " + TOKEN,
            "Bearer wrong",
        ]:
            with self.subTest(header=header):
                self.assertFalse(llm.token_matches(header))

    def test_invalid_configured_token(self):
        for token in [
            "",
            "short",
            "x" * 31,
            "x" * 32 + "\n",
            "x" * 32 + "\r",
            "x" * 32 + chr(127),
            "x" * 32 + chr(233),
        ]:
            with (
                self.subTest(token=repr(token)),
                patch.dict(os.environ, {"SOC_LLM_PROBE_TOKEN": token}),
            ):
                self.assertFalse(llm.token_matches("Bearer " + token))

    def test_operator_token_printable_ascii_boundaries(self):
        for token in [" " * 32, "~" * 32, "x" * 32]:
            with (
                self.subTest(token=repr(token)),
                patch.dict(os.environ, {"SOC_LLM_PROBE_TOKEN": token}),
            ):
                self.assertTrue(llm.token_matches("Bearer " + token))

    def test_non_ascii_supplied_token_safely_rejected(self):
        for header in ["Bearer " + chr(233) * 32, "Bearer " + chr(0x2603) * 32]:
            with self.subTest(header=repr(header)):
                self.assertFalse(llm.token_matches(header))

    def test_token_comparison_uses_compare_digest(self):
        with patch("hmac.compare_digest", wraps=llm.hmac.compare_digest) as compare:
            self.assertTrue(llm.token_matches("Bearer " + TOKEN))
            compare.assert_called_once()

    def test_missing_key_does_not_open(self):
        with patch.dict(os.environ, {"SOC_LLM_API_KEY": ""}):
            result, calls, _ = self.probe_with()
        self.assertFalse(result)
        self.assertEqual(calls, [])

    def test_successful_probe(self):
        result, calls, response = self.probe_with()
        self.assertTrue(result)
        self.assertEqual(len(calls), 1)
        self.assertTrue(response.closed)

    def test_fixed_request_url_method_body_headers(self):
        result, calls, _ = self.probe_with()
        self.assertTrue(result)
        request, timeout = calls[0]
        self.assertEqual(request.full_url, URL)
        self.assertEqual(request.get_method(), "POST")
        self.assertEqual(json.loads(request.data), EXPECTED)
        self.assertEqual(
            {k.lower(): v for k, v in request.header_items()},
            {
                "authorization": "Bearer " + KEY,
                "content-type": "application/json",
                "accept": "application/json",
            },
        )
        self.assertGreater(timeout, 0)
        self.assertLessEqual(timeout, 10)

    def test_arbitrary_nonempty_content_passes(self):
        for content in ["other provider text", "  other text\n", "\u2003value\u2003"]:
            with self.subTest(content=content):
                self.assertTrue(self.probe_with(Response(answer(content)))[0])

    def test_whitespace_only_content_fails(self):
        for content in ["", "  \t\r\n", "\u2003\u2009"]:
            with self.subTest(content=repr(content)):
                self.assertFalse(self.probe_with(Response(answer(content)))[0])

    def test_invalid_response_shapes(self):
        for document in [
            None,
            [],
            {},
            {"choices": []},
            {"choices": {}},
            {"choices": [None]},
            {"choices": [{"message": None}]},
            {"choices": [{"message": {}}]},
            {"choices": [{"message": {"content": 42}}]},
            {"choices": [{"message": {"content": True}}]},
            {"choices": [None, {"message": {"content": "OK"}}]},
        ]:
            with self.subTest(document=document):
                self.assertFalse(
                    self.probe_with(Response(json.dumps(document).encode()))[0]
                )

    def test_only_first_choice_matters(self):
        body = json.dumps(
            {"choices": [{"message": {"content": "valid"}}, None]}
        ).encode()
        self.assertTrue(self.probe_with(Response(body))[0])

    def test_invalid_json_and_utf8_fail(self):
        for body in [b"not-json", b"", b"\xff", b'{"choices":']:
            with self.subTest(body=body):
                self.assertFalse(self.probe_with(Response(body))[0])

    def test_non_200_statuses_fail_without_retry(self):
        for status in [201, 204, 301, 302, 307, 308, 400, 401, 429, 500, 503]:
            with self.subTest(status=status):
                result, calls, response = self.probe_with(Response(status=status))
                self.assertFalse(result)
                self.assertEqual(len(calls), 1)
                self.assertEqual(response.pos, 0)

    def test_content_type_is_not_required(self):
        response = Response()
        response.headers = {"Content-Type": "text/plain"}
        self.assertTrue(self.probe_with(response)[0])

    def test_body_at_limit_passes(self):
        body = answer()
        body += b" " * (65536 - len(body))
        self.assertTrue(self.probe_with(Response(body))[0])

    def test_oversized_body_fails_and_reads_bounded(self):
        body = answer() + b" " * 70000
        result, _, response = self.probe_with(Response(body))
        self.assertFalse(result)
        self.assertLessEqual(response.pos, 65537)
        self.assertTrue(all(0 < size <= 65537 for size in response.read_sizes))

    def test_short_reads_accumulate_until_eof(self):
        self.assertTrue(self.probe_with(Response(chunk_size=7))[0])

    def test_network_and_tls_errors_fail_without_retry(self):
        for error in [
            URLError("synthetic network error"),
            OSError("synthetic socket error"),
            TimeoutError(),
            ssl.SSLError("synthetic TLS error"),
            HTTPError(URL, 503, "synthetic", {}, None),
            ValueError("synthetic invalid header"),
        ]:
            with self.subTest(error=type(error).__name__):
                result, calls, _ = self.probe_with(open_error=error)
                self.assertFalse(result)
                self.assertEqual(len(calls), 1)

    def test_truncated_response_fails(self):
        result, calls, _ = self.probe_with(
            Response(error=http.client.IncompleteRead(b"partial", 100))
        )
        self.assertFalse(result)
        self.assertEqual(len(calls), 1)

    def test_http_protocol_errors_fail(self):
        self.assertFalse(
            self.probe_with(Response(error=http.client.BadStatusLine("synthetic")))[0]
        )

    def test_deadline_includes_open_and_body_read(self):
        clock = Clock()
        result, _, _ = self.probe_with(
            Response(clock=clock, read_cost=2), clock=clock, open_cost=9
        )
        self.assertFalse(result)

    def test_trickling_body_stops_at_total_deadline(self):
        clock = Clock()
        result, _, response = self.probe_with(
            Response(clock=clock, read_cost=2, chunk_size=7), clock=clock, open_cost=3
        )
        self.assertFalse(result)
        self.assertLessEqual(clock.now, 11)
        self.assertLess(response.pos, len(response.body))

    def test_read_timeout_uses_remaining_budget(self):
        clock = Clock()
        result, _, response = self.probe_with(
            Response(clock=clock, read_cost=0.25, chunk_size=20),
            clock=clock,
            open_cost=3,
        )
        self.assertTrue(result)
        self.assertTrue(
            response.timeouts, "The response socket must use the time remaining."
        )
        self.assertLessEqual(response.timeouts[0], 7)
        self.assertTrue(all(0 < value <= 7 for value in response.timeouts))
        self.assertEqual(response.timeouts, sorted(response.timeouts, reverse=True))

    def test_no_output_or_secret_logging(self):
        out, err = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            self.assertTrue(self.probe_with()[0])
            self.assertFalse(
                self.probe_with(open_error=URLError("synthetic " + KEY))[0]
            )
        self.assertEqual(out.getvalue(), "")
        self.assertEqual(err.getvalue(), "")

    def transport(self):
        captured = {}

        class Connection:
            debuglevel = 0

            def __init__(self, host, **kwargs):
                captured["host"] = host
                captured["connection_args"] = kwargs
                self.sock = None

            def set_debuglevel(self, *args):
                pass

            def set_tunnel(self, *args, **kwargs):
                captured["tunnel"] = [args, kwargs]

            def request(self, method, url, body=None, headers=None, **kwargs):
                captured.update(method=method, url=url, body=body, headers=headers)

            def getresponse(self):
                return Response()

            def close(self):
                pass

        with patch("http.client.HTTPSConnection", Connection):
            request = Request(
                URL,
                data=json.dumps(EXPECTED).encode(),
                method="POST",
                headers={
                    "Authorization": "Bearer " + KEY,
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                },
            )
            response = llm._opener().open(request, timeout=10)
            response.close()
        return captured

    def test_transport_does_not_use_environment_proxy(self):
        with patch.dict(
            os.environ,
            {
                "https_proxy": "http://synthetic.invalid:8123",
                "HTTPS_PROXY": "http://synthetic.invalid:8123",
                "no_proxy": "",
                "NO_PROXY": "",
            },
        ):
            captured = self.transport()
        self.assertEqual(captured["host"], "soclaas-api.comp.nus.edu.sg")
        self.assertNotIn("tunnel", captured)

    def test_transport_sends_no_user_agent_or_extra_headers(self):
        headers = {k.lower(): v for k, v in self.transport()["headers"].items()}
        self.assertNotIn("user-agent", headers)
        self.assertLessEqual(
            set(headers),
            {
                "authorization",
                "content-type",
                "accept",
                "host",
                "content-length",
                "connection",
                "accept-encoding",
            },
        )

    def test_transport_uses_verified_system_tls(self):
        captured = self.transport()
        context = captured["connection_args"].get("context")
        self.assertIsNotNone(context)
        self.assertTrue(context.check_hostname)
        self.assertEqual(context.verify_mode, ssl.CERT_REQUIRED)

    def test_redirects_are_refused(self):
        for code in [301, 302, 303, 307, 308]:
            with self.subTest(code=code):
                self.assertIsNone(
                    llm._NoRedirect().redirect_request(
                        Request(URL),
                        None,
                        code,
                        "synthetic",
                        {},
                        "https://synthetic.invalid/",
                    )
                )


if __name__ == "__main__":
    unittest.main(verbosity=2)
