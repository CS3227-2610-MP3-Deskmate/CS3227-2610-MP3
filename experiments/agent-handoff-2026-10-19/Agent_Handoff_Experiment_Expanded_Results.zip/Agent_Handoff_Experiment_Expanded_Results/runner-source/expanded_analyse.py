"""Build separate expanded results while preserving the original artifacts."""

import html
import json
import re
import shutil
import xml.etree.ElementTree as ET
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import analyse
import audit_extension
import extend_generate
import run

ROOT = run.ROOT
EXT = ROOT / "extension-two-histories"
OUT = ROOT / "expanded-results"
OLD = ROOT / "final-results"


def save(name, value):
    run.write_json(OUT / name, value)


def aggregate(rows):
    result = []
    for model in run.MODELS:
        for fmt in run.FORMATS:
            selected = [
                r for r in rows if r["handoff_model"] == model and r["format"] == fmt
            ]
            counts = Counter(r["outcome"] for r in selected)
            result.append(
                {
                    "handoff_model": model,
                    "format": fmt,
                    **{k: counts[k] for k in analyse.OUTCOMES},
                    "denominator": len(selected),
                    "correct_percent": round(
                        100 * counts["correct"] / len(selected), 4
                    ),
                }
            )
    return result


def verify_original():
    for name, sha in run.read_json(EXT / "original-artifact-hashes.json").items():
        assert run.digest(ROOT / name) == sha, "Original artifact changed: " + name


def comparison_chart(before, after):
    svg = [
        '<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="650" viewBox="0 0 1000 650" role="img" aria-labelledby="title desc">',
        '<title id="title">Three-history versus five-history recovery rates</title>',
        '<desc id="desc">Pooled correct-fact percentages before and after the two-history exploratory extension.</desc>',
        '<rect width="1000" height="650" fill="white"/>',
        '<g font-family="Arial,sans-serif" fill="#17202a">',
        '<text x="25" y="32" font-size="23" font-weight="bold">Did two more histories change the results?</text>',
        '<text x="25" y="60" font-size="15">Pooled rates, not averages · same prompts, models, questions and grading rules</text>',
    ]
    for tick in range(0, 101, 20):
        x = 220 + tick * 5.5
        svg.append(
            f'<line x1="{x}" y1="90" x2="{x}" y2="560" stroke="#e3e7ed"/><text x="{x}" y="582" text-anchor="middle" font-size="14">{tick}%</text>'
        )
    for i, (old, new) in enumerate(zip(before, after, strict=True)):
        y = 96 + i * 57
        label = analyse.LABELS[new["handoff_model"]] + " / " + new["format"]
        svg.append(
            f'<text x="207" y="{y + 25}" text-anchor="end" font-size="15">{label}</text>'
        )
        for j, (item, color) in enumerate([(old, "#8197b3"), (new, "#26734d")]):
            top = y + j * 22
            width = 5.5 * item["correct_percent"]
            svg.append(
                f'<rect x="220" y="{top}" width="{width:.2f}" height="17" fill="{color}"/><text x="{230 + width:.2f}" y="{top + 14}" font-size="13">{item["correct_percent"]:.1f}% ({item["correct"]}/{item["denominator"]})</text>'
            )
    svg.extend(
        [
            '<rect x="250" y="612" width="18" height="18" fill="#8197b3"/><text x="278" y="627" font-size="15">Original 3 histories</text>',
            '<rect x="510" y="612" width="18" height="18" fill="#26734d"/><text x="538" y="627" font-size="15">Expanded 5 histories</text>',
            "</g></svg>",
        ]
    )
    return "\n".join(svg)


def main():
    verify_original()
    extend_generate.verify()
    audit_extension.main()
    OUT.mkdir(exist_ok=True)
    judgments = run.read_json(EXT / "judgments.json")
    old_rows = run.read_json(OLD / "fact-scores.json")
    new_rows = []
    words = run.read_json(OLD / "word-counts.json")
    support = []
    formats = run.read_json(OLD / "format-review.json")["rows"]
    expected_cells = set()
    source_lengths = run.read_json(OLD / "source-lengths.json")
    new_keys = {}
    for n in [4, 5]:
        run_id = f"coding-{n:02}"
        source = ROOT / "runs" / run_id
        key = run.read_json(EXT / "frozen" / f"{run_id}-answer-key.json")
        new_keys[run_id] = key
        history = run.read_json(source / "handoff-history.json")
        text = (source / "handoff-history.txt").read_text(encoding="utf-8")
        source_lengths.append(
            {
                "run_id": run_id,
                "characters": len(text),
                "utf8_bytes": len(text.encode("utf-8")),
                "whitespace_words": len(text.split()),
                "history_sha256": run.digest(source / "handoff-history.txt"),
                "patch_sha256": run.digest(source / "repair.patch"),
            }
        )
        for fact in key["facts"]:
            for e in fact["source_evidence"]:
                assert any(
                    e["excerpt"] in s for s in analyse.flat_strings(history[e["entry"]])
                ), (run_id, fact["id"])
        for model in run.MODELS:
            for fmt in run.FORMATS:
                identifier = "|".join([run_id, model, fmt])
                expected_cells.add(identifier)
                annotation = judgments["cells"][identifier]
                correct = set(annotation["correct"])
                wrong = annotation.get("wrong", {})
                valid = {f["id"] for f in key["facts"]}
                assert (
                    correct <= valid
                    and set(wrong) <= valid
                    and not correct.intersection(wrong)
                )
                hd = source / "handoffs" / model / fmt
                rd = source / "receivers" / model / fmt
                handoff = (hd / "output.txt").read_text(encoding="utf-8")
                word_count = len(handoff.split())
                assert (
                    word_count == run.read_json(hd / "format-check.json")["word_count"]
                )
                words.append(
                    {
                        "run_id": run_id,
                        "handoff_model": model,
                        "format": fmt,
                        "word_count": word_count,
                        "within_200_words": word_count <= 200,
                    }
                )
                flags = []
                if fmt == "prose":
                    for line in handoff.splitlines():
                        if re.match(r"^\s*(?:[-*+]\s+|\d+[.)]\s+|#{1,6}\s+)", line):
                            flags.append(
                                {
                                    "kind": "unambiguous prose list/heading",
                                    "evidence": line,
                                }
                            )
                formats.append(
                    {
                        "run_id": run_id,
                        "handoff_model": model,
                        "assigned_format": fmt,
                        "word_count": word_count,
                        "within_200_words": word_count <= 200,
                        "clear_format_flags": flags,
                    }
                )
                answers = {
                    a["id"]: a for a in run.read_json(rd / "answers.json")["answers"]
                }
                validation = run.read_json(rd / "answer-validation.json")
                for unmatched in validation["unmatched_quotes"]:
                    support.append(
                        {"cell": identifier, "kind": "unmatched quote", **unmatched}
                    )
                support.extend(
                    {"cell": identifier, **f}
                    for f in annotation.get("support_flags", [])
                )
                for fact in key["facts"]:
                    evidence_ids = annotation.get("evidence_questions", {}).get(
                        fact["id"], [fact["question_id"]]
                    )
                    outcome = (
                        "correct"
                        if fact["id"] in correct
                        else "wrong"
                        if fact["id"] in wrong
                        else "not stated"
                    )
                    reason = (
                        "Expected semantic claim is explicit in the full quiz or its supporting quotes."
                        if outcome == "correct"
                        else wrong[fact["id"]]
                        if outcome == "wrong"
                        else "Expected claim is absent from the full quiz; absence is not scored wrong."
                    )
                    reason = annotation.get("fact_reasons", {}).get(fact["id"], reason)
                    new_rows.append(
                        {
                            "run_id": run_id,
                            "handoff_model": model,
                            "format": fmt,
                            "question_id": fact["question_id"],
                            "fact_id": fact["id"],
                            "expected_fact": fact["claim"],
                            "source_evidence": fact["source_evidence"],
                            "receiver_evidence_question_ids": evidence_ids,
                            "receiver_answer": "\n".join(
                                (f"[{q}] " if q != fact["question_id"] else "")
                                + answers[q]["answer"]
                                for q in evidence_ids
                            ),
                            "supporting_quotes": [
                                quote
                                for q in evidence_ids
                                for quote in answers[q]["quotes"]
                            ],
                            "outcome": outcome,
                            "reason": reason,
                        }
                    )
    assert set(judgments["cells"]) == expected_cells and len(expected_cells) == 16
    rows = old_rows + new_rows
    assert rows[: len(old_rows)] == old_rows
    before = aggregate(old_rows)
    added = aggregate(new_rows)
    after = aggregate(rows)
    changes = []
    for a, b, c in zip(before, added, after, strict=True):
        changes.append(
            {
                "handoff_model": c["handoff_model"],
                "format": c["format"],
                "original_three": a,
                "added_two": b,
                "expanded_five": c,
                "change_percentage_points": round(
                    c["correct_percent"] - a["correct_percent"], 4
                ),
            }
        )
    effects = []
    for model in run.MODELS:

        def delta(metrics):
            values = {
                m["format"]: m["correct_percent"]
                for m in metrics
                if m["handoff_model"] == model
            }
            return round(values["checklist"] - values["prose"], 4)

        effects.append(
            {
                "handoff_model": model,
                "original_three_checklist_minus_prose_pp": delta(before),
                "added_two_checklist_minus_prose_pp": delta(added),
                "expanded_five_checklist_minus_prose_pp": delta(after),
            }
        )
    save("format-effect-before-after.json", effects)
    paired = []
    sensitivity = []
    for n in range(1, 6):
        run_id = f"coding-{n:02}"
        for model in run.MODELS:
            chosen = [
                r for r in rows if r["run_id"] == run_id and r["handoff_model"] == model
            ]
            counts = {
                fmt: Counter(r["outcome"] for r in chosen if r["format"] == fmt)
                for fmt in run.FORMATS
            }
            pairwords = {
                w["format"]: w["word_count"]
                for w in words
                if w["run_id"] == run_id and w["handoff_model"] == model
            }
            denominator = len(chosen) // 2
            paired.append(
                {
                    "run_id": run_id,
                    "handoff_model": model,
                    "denominator_per_format": denominator,
                    "prose": dict(counts["prose"]),
                    "checklist": dict(counts["checklist"]),
                    "checklist_minus_prose_correct": counts["checklist"]["correct"]
                    - counts["prose"]["correct"],
                    "both_within_word_limit": all(w <= 200 for w in pairwords.values()),
                }
            )
    for model in run.MODELS:
        compliant = {
            p["run_id"]
            for p in paired
            if p["handoff_model"] == model and p["both_within_word_limit"]
        }
        for fmt in run.FORMATS:
            chosen = [
                r
                for r in rows
                if r["handoff_model"] == model
                and r["format"] == fmt
                and r["run_id"] in compliant
            ]
            counts = Counter(r["outcome"] for r in chosen)
            sensitivity.append(
                {
                    "handoff_model": model,
                    "format": fmt,
                    "compliant_paired_histories": sorted(compliant),
                    **{k: counts[k] for k in analyse.OUTCOMES},
                    "denominator": len(chosen),
                    "correct_percent": round(100 * counts["correct"] / len(chosen), 4)
                    if chosen
                    else None,
                }
            )
    grouping = defaultdict(Counter)
    for r in rows:
        grouping[(r["handoff_model"], r["format"], r["question_id"])][r["outcome"]] += 1
    qresults = [
        {
            "handoff_model": m,
            "format": f,
            "question_id": q,
            **{name: c[name] for name in analyse.OUTCOMES},
            "denominator": sum(c.values()),
        }
        for (m, f, q), c in sorted(grouping.items())
    ]
    original_observations = run.read_json(OLD / "observations.json")
    observations = {
        "original_review": original_observations["manual_review"],
        "added_review": judgments.get("observations", []),
        "support_flags": original_observations["support_flags"] + support,
    }
    for name, value in [
        ("fact-scores.json", rows),
        ("added-fact-scores.json", new_rows),
        ("before-after.json", changes),
        ("model-format-results.json", after),
        ("additional-two-results.json", added),
        ("question-results.json", qresults),
        ("paired-results.json", paired),
        ("compliant-pair-sensitivity.json", sensitivity),
        ("word-counts.json", words),
        (
            "format-review.json",
            {
                "rows": formats,
                "rule": "Same unambiguous list/heading diagnostics as the original report; inline labels alone are not counted as headings.",
            },
        ),
        ("observations.json", observations),
        ("source-lengths.json", source_lengths),
        ("extension-judgments.json", judgments),
    ]:
        save(name, value)
    svg = (
        analyse.chart(after)
        .replace("three coding histories", "five coding histories")
        .replace("three histories", "five histories")
    )
    (OUT / "comparison.svg").write_text(svg, encoding="utf-8")
    (OUT / "before-after.svg").write_text(
        comparison_chart(before, after), encoding="utf-8"
    )
    for n in range(1, 6):
        run_id = f"coding-{n:02}"
        source = ROOT / "runs" / run_id
        target = OUT / "evidence" / run_id
        target.mkdir(parents=True, exist_ok=True)
        for name in [
            "handoff-history.txt",
            "handoff-history.json",
            "repair.patch",
            "audit.json",
        ]:
            shutil.copyfile(source / name, target / name)
        for model in run.MODELS:
            for fmt in run.FORMATS:
                folder = target / model / fmt
                folder.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(
                    source / "handoffs" / model / fmt / "output.txt",
                    folder / "handoff.txt",
                )
                shutil.copyfile(
                    source / "receivers" / model / fmt / "answers.json",
                    folder / "answers.json",
                )
    for filename in run.read_json(EXT / "original-artifact-hashes.json"):
        source = ROOT / filename
        if source.is_relative_to(OLD):
            target = OUT / "original-three-histories" / source.relative_to(OLD)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
    for p in (EXT / "frozen").glob("*.json"):
        target = OUT / "extension-frozen" / p.name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(p, target)
    for name in [
        "plan.json",
        "original-artifact-hashes.json",
        "coding-replay-verification.json",
        "cli-audit.json",
    ]:
        save("extension-" + name, run.read_json(EXT / name))
    old_audit = run.read_json(OLD / "cli-audit.json")
    added_audit = run.read_json(EXT / "cli-audit.json")
    all_calls = old_audit["calls"] + added_audit["calls"]
    assert len(all_calls) == 110
    save(
        "cli-audit.json",
        {
            "calls": all_calls,
            "completed_scored_calls_audited": len(all_calls),
            "native_forbidden_events": sum(
                len(c["forbidden_events"]) for c in all_calls
            ),
            "incomplete_client_audits": sum(
                not c["complete_client_evidence"] for c in all_calls
            ),
            "limitation": old_audit["limitation"],
        },
    )
    findings = run.read_json(EXT / "findings.json")

    def rates(item):
        return (
            f"{item['correct']}/{item['denominator']} ({item['correct_percent']:.1f}%)"
        )

    changes_table = analyse.table(
        [
            "Model",
            "Format",
            "Original 3 histories",
            "Added 2 histories",
            "Expanded 5 histories",
            "Change, pp",
        ],
        [
            [
                analyse.LABELS[c["handoff_model"]],
                c["format"],
                rates(c["original_three"]),
                rates(c["added_two"]),
                rates(c["expanded_five"]),
                f"{c['change_percentage_points']:+.1f}",
            ]
            for c in changes
        ],
    )
    pairs_table = analyse.table(
        [
            "History",
            "Model",
            "Prose correct",
            "Checklist correct",
            "Denominator each",
            "Checklist − prose",
            "Both within 200",
        ],
        [
            [
                p["run_id"],
                analyse.LABELS[p["handoff_model"]],
                p["prose"].get("correct", 0),
                p["checklist"].get("correct", 0),
                p["denominator_per_format"],
                p["checklist_minus_prose_correct"],
                p["both_within_word_limit"],
            ]
            for p in paired
        ],
    )
    sensitivity_table = analyse.table(
        [
            "Model",
            "Format",
            "Compliant paired histories",
            "Correct",
            "Denominator",
            "Correct %",
        ],
        [
            [
                analyse.LABELS[s["handoff_model"]],
                s["format"],
                len(s["compliant_paired_histories"]),
                s["correct"],
                s["denominator"],
                f"{s['correct_percent']:.1f}"
                if s["correct_percent"] is not None
                else None,
            ]
            for s in sensitivity
        ],
    )
    question_table = analyse.table(
        ["Model", "Format", "Topic", "Correct", "Not stated", "Wrong", "Denominator"],
        [
            [
                analyse.LABELS[q["handoff_model"]],
                q["format"],
                q["question_id"],
                q["correct"],
                q["not stated"],
                q["wrong"],
                q["denominator"],
            ]
            for q in qresults
        ],
    )
    words_table = analyse.table(
        ["History", "Model", "Format", "Words", "Within 200"],
        [
            [
                w["run_id"],
                analyse.LABELS[w["handoff_model"]],
                w["format"],
                w["word_count"],
                w["within_200_words"],
            ]
            for w in words
        ],
    )
    data = '<html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Expanded agent handoff experiment</title><style>body{max-width:1100px;margin:36px auto;padding:0 22px;font:17px/1.55 system-ui,sans-serif;color:#17202a}h1,h2{line-height:1.2}table{border-collapse:collapse;width:100%;font-size:14px;margin:20px 0}td,th{border:1px solid #d9dee5;padding:7px;text-align:left}th{background:#eef2f6}tr:nth-child(even){background:#fafbfc}img{max-width:100%;height:auto}a{color:#165a97}.note{border-left:4px solid #b74426;padding-left:16px}</style><h1>Two more coding histories: did the results change?</h1>'
    data += "<p>Five independent Opus 5.5 coding histories, four handoff models and two assigned formats: 40 handoffs and 40 separate Opus 5.5 receiving quizzes. This extension adds 2 coding histories, 16 handoffs and 16 quizzes to the preserved original study.</p>"
    data += "".join("<p>" + html.escape(p) + "</p>" for p in findings["paragraphs"])
    data += (
        '<img src="before-after.svg" alt="Original three-history versus expanded five-history recovery percentages"><h2>Before and after</h2><p>Counts are pooled totals, not averages. The original denominator is 27 + 27 + 28 = 82 facts per model/format; the two added histories each contribute 27, giving 136 in the expanded comparison. A percentage-point change compares correct/denominator, rather than raw counts across different sample sizes.</p>'
        + changes_table
    )
    data += (
        '<h2>Expanded format comparison</h2><img src="comparison.svg" alt="Correct, omitted and wrong facts across five shared histories"><p>Primary counts retain every output as produced. Expected facts absent from source evidence are excluded rather than treated as lost. The fact inventory is fixed for every model and format within a history.</p><h2>Paired histories</h2>'
        + pairs_table
    )
    data += (
        "<h2>Word budget and sensitivity</h2><p>Words are whitespace-delimited, including labels. No overlength output was trimmed or regenerated. The predeclared sensitivity includes only histories where both formats for that model stayed within 200 words.</p>"
        + sensitivity_table
        + words_table
    )
    data += (
        "<h2>Per-question topic counts</h2><p>Q1 changed files; Q2 checks/outcomes; Q3 verification limits; Q4 total timeout; Q5 successful provider responses; Q6 proxy/header behaviour. Credit is given for an explicit fact anywhere in the full six-answer reply or its quotes. Cross-question evidence locations are recorded in the fact rows.</p>"
        + question_table
    )
    data += (
        "<h2>Separate claim observations</h2><p>Additional false statements, ambiguous wording and support issues are separate from expected-fact omissions. Original observations remain unchanged in the preserved report.</p><ul>"
        + "".join(
            "<li>"
            + html.escape(o.get("summary", json.dumps(o, ensure_ascii=False)))
            + "</li>"
            for o in judgments.get("observations", [])
        )
        + "</ul>"
    )
    data += '<h2>Method, extension and limitations</h2><p class="note">The user requested two more histories after seeing the first three results. This is an exploratory extension, not a preregistered five-history confirmatory study. There is one coding task, one sample per history/model/format and a fixed Opus writer and decoder. Shared facts and histories are not independent study replications. No statistical significance or general frontier-model ranking is claimed.</p>'
    data += "<p>Models, installed clients, medium effort, default temperature, 200-word prompts, questions, fact definitions and grading interpretation were retained. New keys were frozen only after both new coding histories existed and before their handoffs. The original 656 labels and all original report/ZIP files were preserved byte-for-byte. Each new coding continuation excludes raw transcript export metadata, reproducing the original replay format; all 18 original coding prompts were reconstructed exactly as a consistency check.</p>"
    data += "<p>One incomplete setup attempt used an already-imported runner before its replay fix was reloaded. Three reads completed; its first write request was cancelled without a returned repair. Its raw evidence was preserved and excluded before scored handoffs, and the valid histories restarted with verified serialization. The earlier study also disclosed its separate transcript-rendering correction and eight excluded preliminary handoffs. See the preserved original report and extension plan for provenance.</p>"
    data += "<p>All five valid repairs passed the same 30 offline tests. Baseline/reference validation is unchanged: the starting code failed 5 tests and errored on 4; the private reference passed all 30. Runtime used the same pinned image, no network, read-only workspace mount and unprivileged user. Only llm.py could be edited; no live provider, deployment, Django/database integration or real production deadline guarantee was established. No app repository code was changed.</p>"
    data += "<p>Claude sessions exposed no tools. OpenAI retained native tool schemas under the user-accepted audited-session exception. No native tool calls or incomplete final client audits were recorded; the audit is limited to client-visible events. Public model IDs and reported model names are pinned, but immutable service snapshots are not guaranteed. Temperature is not exposed by these subscription clients, and medium effort is not equal compute across providers.</p>"
    data += "<p>Fact labels were assigned by the Codex assistant in the experimenter role, with model and format visible and without an independent human grader. The full-quiz interpretation was clarified during the original unblinded review and retained here. Accurate facts with weak handoff support are flagged separately. The shared handoff prompt asks for a work summary rather than explicitly requesting every quiz topic; omissions measure this particular pipeline and prompt.</p>"
    data += '<h2>Artifacts</h2><p><a href="original-three-histories/report.html">Preserved original three-history report</a> · <a href="before-after.json">Before/after data</a> · <a href="fact-scores.json">Every expanded fact judgment</a> · <a href="added-fact-scores.json">Added judgments only</a> · <a href="observations.json">Claim/support observations</a> · <a href="cli-audit.json">Client audit</a> · <a href="extension-frozen/extension-plan.json">Extension plan</a>. Source histories, patches, handoffs and quizzes are in evidence/. This explicit export excludes credentials, client-home and private reference repairs.</p></html>'
    (OUT / "report.html").write_text("<!doctype html>" + data, encoding="utf-8")
    for p in ["comparison.svg", "before-after.svg"]:
        ET.parse(OUT / p)
    assert len(new_rows) == 432 and len(rows) == 1088
    assert len(
        {(r["run_id"], r["handoff_model"], r["format"], r["fact_id"]) for r in rows}
    ) == len(rows)
    assert not (run.PRIVATE / "client-home" / "auth.json").exists()
    verify_original()
    save(
        "STATUS.json",
        {
            "stage": "Complete: 5 coding histories, 40 handoffs, 40 quizzes, 1088 fact judgments",
            "completed_at_utc": datetime.now(timezone.utc).isoformat(),
            "additional_coding_histories": 2,
            "additional_handoffs": 16,
            "additional_quizzes": 16,
            "original_artifacts_preserved": True,
        },
    )
    source_code = OUT / "runner-source"
    source_code.mkdir(exist_ok=True)
    for name in [
        "run.py",
        "appserver_backend.py",
        "extend_keys.py",
        "extend_generate.py",
        "audit_extension.py",
        "expanded_analyse.py",
    ]:
        shutil.copyfile(ROOT / name, source_code / name)
    (OUT / "README.txt").write_text(
        "Open report.html for the expanded five-history results and before/after comparison. The original three-history report is preserved in original-three-histories/. Counts are pooled, not averages. Only the new two histories were generated in this extension; all original judgments are unchanged. New model outputs and code are in evidence/ and runner-source/. Frozen new keys and original prompts are in extension-frozen/. Raw native calls, the excluded setup attempt and private runtime configuration remain in the parent experiment folder. This shareable folder excludes credential files, client-home and private reference repairs.\n",
        encoding="utf-8",
    )
    files = sorted(p for p in OUT.rglob("*") if p.is_file())
    for p in files:
        assert (
            not p.is_symlink()
            and p.name.lower() not in {"auth.json", ".env"}
            and "client-home" not in p.parts
        )
    save(
        "artifact-sha256.json",
        {
            str(p.relative_to(OUT)): run.digest(p)
            for p in files
            if p != OUT / "artifact-sha256.json"
        },
    )
    archive_path = ROOT / "Agent_Handoff_Experiment_Expanded_Results.zip"
    with ZipFile(archive_path, "w", compression=ZIP_DEFLATED) as archive:
        for p in sorted(p for p in OUT.rglob("*") if p.is_file()):
            archive.write(
                p,
                arcname=Path("Agent_Handoff_Experiment_Expanded_Results")
                / p.relative_to(OUT),
            )
    with ZipFile(archive_path) as archive:
        assert archive.testzip() is None
    run.write_json(
        ROOT / "STATUS.json",
        {
            "stage": "Expanded experiment complete",
            "valid_coding_histories": 5,
            "handoffs": 40,
            "receiving_quizzes": 40,
            "fact_judgments": 1088,
            "original_results": "final-results/report.html",
            "expanded_results": "expanded-results/report.html",
            "original_artifacts_preserved": True,
            "temporary_native_signin_link_removed": True,
        },
    )
    run.write_json(
        EXT / "STATUS.json",
        {
            "stage": "Complete: two added histories, 16 handoffs, 16 quizzes; expanded results exported",
            "new_fact_rows": 432,
            "total_fact_rows": 1088,
        },
    )
    print(
        json.dumps(
            {
                "before_after": changes,
                "new_rows": len(new_rows),
                "total_rows": len(rows),
                "word_limit_violations": sum(not w["within_200_words"] for w in words),
                "new_support_flags": len(support),
                "report": str(OUT / "report.html"),
                "zip": str(archive_path),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
