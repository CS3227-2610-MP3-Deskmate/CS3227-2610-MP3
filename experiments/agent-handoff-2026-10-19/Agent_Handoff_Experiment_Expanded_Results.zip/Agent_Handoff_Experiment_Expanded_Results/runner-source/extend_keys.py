"""Freeze source-based answer keys for only the two added histories."""

import copy
import re
import shutil
from datetime import datetime, timezone

import analyse
import run

EXTENSION = run.ROOT / "extension-two-histories"


def main():
    for n in [4, 5]:
        assert (run.ROOT / "runs" / f"coding-{n:02}" / "audit.json").exists()
    frozen = EXTENSION / "frozen"
    frozen.mkdir(exist_ok=False)
    for name in [
        "questions.json",
        "coding-prompt.json",
        "handoff-prompts.json",
        "receiver-prompt.json",
        "models.json",
        "score-rules.json",
        "pre-scored-settings.json",
    ]:
        shutil.copyfile(run.ROOT / "frozen" / name, frozen / name)
    shutil.copyfile(EXTENSION / "plan.json", frozen / "extension-plan.json")
    shutil.copyfile(EXTENSION / "condition-order.json", frozen / "condition-order.json")
    template = run.read_json(run.ROOT / "frozen" / "coding-01-answer-key.json")
    for n in [4, 5]:
        run_id = f"coding-{n:02}"
        folder = run.ROOT / "runs" / run_id
        assert not (folder / "handoffs").exists()
        history = run.read_json(folder / "handoff-history.json")

        def find(role, action, path=None):
            return [
                i
                for i, e in enumerate(history)
                if e["role"] == role
                and isinstance(e["content"], dict)
                and e["content"].get("action") == action
                and (path is None or e["content"].get("path") == path)
            ]

        spec = find("tool", "read_file", "llm-health.md")[0]
        write = find("assistant", "write_file", "llm.py")[-1]
        results = find("tool", "run_tests")
        test = results[-1]
        assert history[test]["content"]["exit_code"] == 0
        message = history[write]["content"]["message"]
        code = history[write]["content"]["content"]
        assert "time.monotonic" in code and "TIMEOUT_SECONDS = 10" in code
        facts = copy.deepcopy(template["facts"])
        for fact in facts:
            fid = fact["id"]
            if fid == "Q1.1":
                fact["source_evidence"] = [
                    {"entry": write + 1, "excerpt": "llm.py"},
                    {"entry": write + 1, "excerpt": "written"},
                ]
            elif fid.startswith("Q2."):
                for e in fact["source_evidence"]:
                    e["entry"] = test
            elif fid.startswith("Q3."):
                for e in fact["source_evidence"]:
                    e["entry"] = 0 if fid in ["Q3.1", "Q3.2", "Q3.7"] else test
            elif fid in ["Q4.1", "Q4.3"]:
                for e in fact["source_evidence"]:
                    e["entry"] = write
            elif fid in ["Q4.2", "Q4.4", "Q6.1", "Q6.2"]:
                fact["source_evidence"] = [{"entry": write, "excerpt": message}]
            elif fid.startswith("Q5."):
                for e in fact["source_evidence"]:
                    e["entry"] = spec
        # Re-anchor rationale by meaning, retaining the frozen semantic claim.
        rationale = []
        for i, e in enumerate(history):
            if e["role"] != "assistant":
                continue
            note = e["content"]["message"]
            if (
                "per-socket" in note
                or "each socket operation" in note
                or "per socket operation" in note
                or "per-operation" in note
                or "per-read timeout" in note
            ) and ("total" in note or "whole" in note):
                rationale.append((i, note))
        reason = next(f for f in facts if f["id"] == "Q4.5")
        if rationale:
            i, note = rationale[0]
            reason["source_evidence"] = [{"entry": i, "excerpt": note}]
        else:
            facts.remove(reason)
        for j, index in enumerate(results[:-1], 1):
            value = history[index]["content"]
            if value["exit_code"] != 0:
                summary = re.search(r"FAILED \([^\n]+\)", value["output"]).group(0)
                facts.append(
                    {
                        "id": f"Q2.B{j}",
                        "question_id": "Q2",
                        "claim": "An earlier recorded suite failed before the final successful check.",
                        "source_evidence": [{"entry": index, "excerpt": summary}],
                        "interpretation": "Same rule used for the original histories; actual recorded failure only.",
                    }
                )
        # Add the same specific DNS/connect/TLS caveat only if this source states it.
        caveats = []
        for i, e in enumerate(history):
            if e["role"] == "assistant":
                note = e["content"]["message"]
                if "DNS" in note and (
                    "cannot" in note or "can't" in note or "not strictly" in note
                ):
                    caveats.append((i, note))
        if caveats:
            extra = copy.deepcopy(
                next(
                    f
                    for f in run.read_json(
                        run.ROOT / "frozen" / "coding-03-answer-key.json"
                    )["facts"]
                    if f["id"] == "Q3.8"
                )
            )
            i, note = caveats[0]
            extra["source_evidence"] = [{"entry": i, "excerpt": note}]
            facts.append(extra)
        for fact in facts:
            for evidence in fact["source_evidence"]:
                assert any(
                    evidence["excerpt"] in text
                    for text in analyse.flat_strings(history[evidence["entry"]])
                ), (run_id, fact["id"])
        key = {
            "run_id": run_id,
            "prepared_at_utc": datetime.now(timezone.utc).isoformat(),
            "history_sha256": run.digest(folder / "handoff-history.txt"),
            "source_policy": template["source_policy"],
            "questions": [
                {
                    "id": q["id"],
                    "status": "scored",
                    "fact_ids": [f["id"] for f in facts if f["question_id"] == q["id"]],
                }
                for q in run.QUESTIONS
            ],
            "facts": facts,
            "extension_policy": "Same claims and atomic inventory policy as the initial three histories; only evidence anchors and source-established optional facts differ.",
        }
        run.write_json(frozen / f"{run_id}-answer-key.json", key)
        print(
            "FROZEN", run_id, len(facts), "source-evidenced expected facts", flush=True
        )
    run.write_json(
        frozen / "frozen-at.json",
        {
            "at_utc": datetime.now(timezone.utc).isoformat(),
            "new_handoffs_started": False,
            "source_histories_complete": 2,
            "original_questions_and_keys_unchanged": True,
        },
    )
    run.write_json(
        frozen / "sha256.json",
        {p.name: run.digest(p) for p in frozen.iterdir() if p.is_file()},
    )


if __name__ == "__main__":
    main()
