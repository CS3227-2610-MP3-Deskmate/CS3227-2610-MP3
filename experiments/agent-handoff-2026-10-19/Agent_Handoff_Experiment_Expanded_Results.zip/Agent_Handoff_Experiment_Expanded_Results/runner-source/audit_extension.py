"""Audit recorded native events and fixed coding action/file restrictions."""

import json
from collections import Counter

import run


def main():
    records = []
    for n in range(4, 6):
        run_id = f"coding-{n:02}"
        folder = run.ROOT / "runs" / run_id
        history = run.read_json(folder / "full-history.json")
        actions = [e["content"] for e in history if e["role"] == "assistant"]
        assert set(a["path"] for a in actions if a["action"] == "read_file") == {
            "llm.py",
            "llm-health.md",
            "test_probe.py",
        }
        assert all(
            a["path"] == "llm.py" for a in actions if a["action"] == "write_file"
        )
        assert all(
            a["action"] in {"read_file", "write_file", "run_tests", "finish"}
            for a in actions
        )
        assert actions[-1]["action"] == "finish"
        assert run.read_json(folder / "handoff-history.json")[-1]["role"] == "tool"
        initial = run.read_json(folder / "initial-manifest.json")
        for name in ["llm-health.md", "test_probe.py"]:
            assert run.digest(run.ROOT / "workspaces" / run_id / name) == initial[name]
        for stage in ["raw", "handoffs", "receivers"]:
            base = folder / stage
            if stage == "raw":
                directories = sorted(
                    p.parent for p in base.glob("turn-*/metadata.json")
                )
            else:
                directories = sorted(p.parent for p in base.glob("*/*/metadata.json"))
            for directory in directories:
                meta = run.read_json(directory / "metadata.json")
                assert meta["exit_code"] == 0 and not meta["native_tool_events"]
                evidence_dir = directory
                attempts = directory / "infrastructure-attempts.json"
                if attempts.exists():
                    entries = run.read_json(attempts)
                    successful = [e for e in entries if e["status"] == "success"]
                    if successful:
                        evidence_dir = run.ROOT / successful[-1]["path"]
                model = meta["requested_model"]
                item_types = Counter()
                forbidden = []
                complete = False
                if model.startswith("gpt-"):
                    source = evidence_dir / "appserver-rpc.jsonl"
                    for line in source.read_text(encoding="utf-8").splitlines():
                        record = json.loads(line)
                        if record["direction"] != "receive":
                            continue
                        event = record["message"]
                        method = event.get("method", "")
                        if method and "id" in event:
                            forbidden.append({"server_request_method": method})
                        if method in ["item/started", "item/completed"]:
                            kind = event.get("params", {}).get("item", {}).get("type")
                            item_types[method + ":" + str(kind)] += 1
                            if kind not in ["userMessage", "agentMessage", "reasoning"]:
                                forbidden.append(
                                    {"item_method": method, "item_type": kind}
                                )
                        if method == "turn/completed":
                            complete = (
                                event.get("params", {}).get("turn", {}).get("status")
                                == "completed"
                            )
                else:
                    source = evidence_dir / "stdout.jsonl"
                    for line in source.read_text(encoding="utf-8").splitlines():
                        event = json.loads(line)
                        if (
                            event.get("type") == "system"
                            and event.get("subtype") == "init"
                        ):
                            if event.get("tools") or event.get("mcp_servers"):
                                forbidden.append(
                                    {
                                        "available_tools": event.get("tools"),
                                        "mcp_servers": event.get("mcp_servers"),
                                    }
                                )
                        if event.get("type") == "assistant":
                            for block in event.get("message", {}).get("content", []):
                                item_types[block.get("type", "unknown")] += 1
                                if block.get("type") == "tool_use":
                                    forbidden.append({"tool_name": block.get("name")})
                        if event.get("type") == "result":
                            complete = event.get(
                                "subtype"
                            ) == "success" and not event.get("is_error", False)
                records.append(
                    {
                        "run_id": run_id,
                        "stage": stage,
                        "path": str(directory.relative_to(run.ROOT)),
                        "requested_model": model,
                        "actual_reported_models": meta["actual_model_ids_reported"],
                        "native_items": dict(item_types),
                        "forbidden_events": forbidden,
                        "complete_client_evidence": complete,
                        "evidence_path": str(source.relative_to(run.ROOT)),
                        "evidence_sha256": run.digest(source),
                    }
                )
    result = {
        "calls": records,
        "completed_scored_calls_audited": len(records),
        "native_forbidden_events": sum(len(r["forbidden_events"]) for r in records),
        "incomplete_client_audits": sum(
            not r["complete_client_evidence"] for r in records
        ),
        "coding_file_restrictions_checked": True,
        "static_patch_review": {
            "review": "Experimenter review of the two added repair patches is recorded with the extension judgments. Changes stay in the probe module, add only standard-library code, retain the fixed provider destination and contain no subprocess or filesystem-write additions. This is a review observation, not a proof of production correctness.",
            "patch_sha256": {
                f"coding-{n:02}": run.digest(
                    run.ROOT / "runs" / f"coding-{n:02}" / "repair.patch"
                )
                for n in range(4, 6)
            },
        },
        "limitation": "Client-visible event audit only; OpenAI native tool schemas remain available under the user-accepted exception.",
    }
    run.write_json(run.ROOT / "extension-two-histories" / "cli-audit.json", result)
    print(
        json.dumps(
            {
                k: v
                for k, v in result.items()
                if k not in ["calls", "static_patch_review"]
            },
            indent=2,
        )
    )
    assert (
        result["native_forbidden_events"] == 0
        and result["incomplete_client_audits"] == 0
    )


if __name__ == "__main__":
    main()
