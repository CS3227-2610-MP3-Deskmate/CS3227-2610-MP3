"""Run only the two new histories' frozen handoff and quiz conditions."""

import atexit
from concurrent.futures import ThreadPoolExecutor, as_completed

import run

EXTENSION = run.ROOT / "extension-two-histories"


def verify():
    run.verify_freeze()
    for name, sha in run.read_json(EXTENSION / "frozen" / "sha256.json").items():
        assert run.digest(EXTENSION / "frozen" / name) == sha, name
    assert run.QUESTIONS == run.read_json(EXTENSION / "frozen" / "questions.json")
    for n in [4, 5]:
        run_id = f"coding-{n:02}"
        key = run.read_json(EXTENSION / "frozen" / f"{run_id}-answer-key.json")
        assert key["history_sha256"] == run.digest(
            run.ROOT / "runs" / run_id / "handoff-history.txt"
        )


def generate(stage):
    verify()
    conditions = run.read_json(EXTENSION / "condition-order.json")
    assert len(conditions) == 16 and {c[0] for c in conditions} == {
        "coding-04",
        "coding-05",
    }
    errors = []
    with ThreadPoolExecutor(max_workers=2) as pool:
        tasks = {
            pool.submit(
                run.handoff if stage == "handoffs" else run.receive, *condition
            ): condition
            for condition in conditions
        }
        for task in as_completed(tasks):
            try:
                task.result()
            except Exception as error:
                errors.append({"condition": tasks[task], "error": str(error)})
    if errors:
        run.write_json(EXTENSION / f"{stage}-errors.json", errors)
        raise RuntimeError(
            f"{len(errors)} extension conditions failed; preserve outputs, never regenerate for quality"
        )


if __name__ == "__main__":
    atexit.register(run.cleanup_client_signin)
    generate("handoffs")
    run.write_json(
        EXTENSION / "STATUS.json",
        {
            "stage": "All 16 added handoffs saved; 16 fixed-Opus receiving quizzes in progress",
            "completed_new_coding_runs": 2,
        },
    )
    generate("receivers")
    run.write_json(
        EXTENSION / "STATUS.json",
        {
            "stage": "All 16 added handoffs and 16 receiving quizzes saved; source-fact grading pending",
            "completed_new_coding_runs": 2,
        },
    )
    print(
        "All 32 additional handoff/quiz outputs saved; original outputs untouched.",
        flush=True,
    )
