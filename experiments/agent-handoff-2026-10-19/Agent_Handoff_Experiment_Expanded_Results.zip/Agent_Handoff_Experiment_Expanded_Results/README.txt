Open report.html for the expanded five-history results and before/after comparison. The original three-history report is preserved in original-three-histories/. Counts are pooled, not averages. Only the new two histories were generated in this extension; all original judgments are unchanged. New model outputs and code are in evidence/ and runner-source/. Frozen new keys and original prompts are in extension-frozen/. Raw native calls, the excluded setup attempt and private runtime configuration remain in the parent experiment folder. This shareable folder excludes credential files, client-home and private reference repairs.

Privacy export: machine-specific paths in archived runner copies are replaced
with named placeholders. Configure those paths before rerunning the sources.
